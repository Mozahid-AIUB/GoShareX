import React, { useEffect, useRef, useState } from 'react';
import {
  Alert,
  Animated,
  Easing,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import { Text } from 'react-native-paper';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Circle, Defs, LinearGradient, Path, Rect, Stop } from 'react-native-svg';

import { useAuthStore } from '@/store/authStore';
import { useRideStore } from '@/store/rideStore';
import rideService from '@/services/firebase/rideService';
import { sendRideConfirmed } from '@/services/notifications/fcmService';
import { recordCancellation } from '@/services/firebase/badgeService';
import { buildRideRoutePreview } from '@/services/ride/routePreviewService';
import type { RideRoutePreview } from '@/types/ride.types';

// ─── Finova tokens ────────────────────────────────────────────────────────────
const C = {
  bg: '#07090F',
  surface: 'rgba(255,255,255,0.055)',
  border: 'rgba(255,255,255,0.09)',
  primary: '#7C6FF7',
  teal: '#14B8A6',
  amber: '#F59E0B',
  red: '#F43F5E',
  green: '#10B981',
  text: '#EEF2FF',
  textSub: '#7B8DB0',
  textMuted: '#343D55',
  white: '#FFFFFF',
};

// ─── SVG Icons ────────────────────────────────────────────────────────────────
const IconCheck = () => (
  <Svg width={44} height={44} viewBox="0 0 48 48" fill="none">
    <Defs>
      <LinearGradient id="chk" x1="0" y1="0" x2="1" y2="1">
        <Stop offset="0" stopColor="#10B981" />
        <Stop offset="1" stopColor="#14B8A6" />
      </LinearGradient>
    </Defs>
    <Circle cx="24" cy="24" r="22" fill="url(#chk)" opacity="0.15" />
    <Circle cx="24" cy="24" r="18" stroke="url(#chk)" strokeWidth="1.5" fill="none" />
    <Path d="M14 24L20 30L34 16" stroke="#10B981" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const IconStart = () => (
  <Svg width={20} height={20} viewBox="0 0 24 24" fill="none">
    <Path d="M5 3l14 9-14 9V3z" fill="#fff" />
  </Svg>
);

const IconCancel = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M18 6L6 18M6 6l12 12" stroke={C.red} strokeWidth="2" strokeLinecap="round" />
  </Svg>
);

const IconPin = () => (
  <Svg width={14} height={14} viewBox="0 0 24 24" fill="none">
    <Path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5S10.62 6.5 12 6.5s2.5 1.12 2.5 2.5S13.38 11.5 12 11.5z" fill={C.primary} />
  </Svg>
);

const IconRoute = () => (
  <Svg width={14} height={14} viewBox="0 0 24 24" fill="none">
    <Path d="M3 17h18M3 12h18M3 7h18" stroke={C.teal} strokeWidth="2" strokeLinecap="round" />
  </Svg>
);

const IconClock = () => (
  <Svg width={14} height={14} viewBox="0 0 24 24" fill="none">
    <Circle cx="12" cy="12" r="9" stroke={C.amber} strokeWidth="1.8" />
    <Path d="M12 7v5l3 3" stroke={C.amber} strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);

const IconMoney = () => (
  <Svg width={14} height={14} viewBox="0 0 24 24" fill="none">
    <Circle cx="12" cy="12" r="9" stroke={C.green} strokeWidth="1.8" />
    <Path d="M12 7v10M9 9.5c0-1.1.9-2 2-2h2a2 2 0 010 4h-2a2 2 0 000 4h2a2 2 0 002-2" stroke={C.green} strokeWidth="1.5" strokeLinecap="round" />
  </Svg>
);

// ─── Main ─────────────────────────────────────────────────────────────────────
export default function RideConfirmedScreen() {
  const route = useRoute<any>();
  const navigation = useNavigation<any>();
  const insets = useSafeAreaInsets();
  const { user } = useAuthStore();
  const { setCurrentRide, setStatus, destination, pickupPoint } = useRideStore();
  const { rider, fare, splitFare, routePreview: incomingRoutePreview } = route.params ?? {};

  const [rideId, setRideId] = useState<string | null>(null);
  const [routePreview, setRoutePreview] = useState<RideRoutePreview | null>(incomingRoutePreview ?? null);
  const [creatingRide, setCreatingRide] = useState(false);

  const resolvedDestination = destination ?? rider?.destination ?? null;
  const resolvedPickup = pickupPoint ?? rider?.pickupPoint ?? 'main_gate';
  const totalFare = routePreview?.soloFare ?? fare ?? 0;
  const totalSplit = routePreview?.splitFare ?? splitFare ?? Math.ceil(totalFare / 2);

  // Animations
  const checkScale = useRef(new Animated.Value(0)).current;
  const cardY = useRef(new Animated.Value(30)).current;
  const cardOpacity = useRef(new Animated.Value(0)).current;
  const ringScale = useRef(new Animated.Value(0.7)).current;
  const ringOpacity = useRef(new Animated.Value(0.8)).current;

  useEffect(() => {
    // Ring pulse then fade
    Animated.sequence([
      Animated.parallel([
        Animated.spring(checkScale, { toValue: 1, tension: 70, friction: 6, useNativeDriver: true }),
        Animated.timing(ringScale, { toValue: 1.6, duration: 700, easing: Easing.out(Easing.quad), useNativeDriver: true }),
        Animated.timing(ringOpacity, { toValue: 0, duration: 700, useNativeDriver: true }),
      ]),
      Animated.parallel([
        Animated.timing(cardOpacity, { toValue: 1, duration: 350, useNativeDriver: true }),
        Animated.spring(cardY, { toValue: 0, tension: 80, friction: 8, useNativeDriver: true }),
      ]),
    ]).start();

    const bootstrap = async () => {
      if (!user || !rider || creatingRide || rideId) return;
      setCreatingRide(true);
      try {
        const preview = incomingRoutePreview ?? await buildRideRoutePreview({
          pickup: resolvedPickup,
          destination: resolvedDestination,
          fallbackFare: fare,
        });
        if (preview) setRoutePreview(preview);

        const id = await rideService.createRide(
          user.uid, user.name,
          rider.userId, rider.name,
          resolvedDestination ?? rider.destination,
          resolvedPickup,
          preview?.soloFare ?? fare ?? 0,
          preview ?? undefined,
        );
        setRideId(id);
        setCurrentRide({ rideId: id, rider1: user.uid, rider2: rider.userId, routePreview: preview ?? null });
        setStatus('matched');
      } catch {
        Alert.alert('Error', 'Unable to create ride. Please try again.');
        navigation.goBack();
      } finally {
        setCreatingRide(false);
      }
    };
    void bootstrap();
  }, []);

  const handleStart = async () => {
    if (!rideId || !rider?.userId) return;
    await rideService.startRide(rideId);

    // Notify the partner that the ride is confirmed
    if (rider?.userId && user?.uid) {
      sendRideConfirmed(rider.userId, user?.name ?? 'Your partner', rideId)
        .catch(e => console.warn('[RideConfirmedScreen] sendRideConfirmed failed:', e));
    }

    setStatus('active');
    navigation.navigate('RideActive', { rideId, rider, fare: totalFare, splitFare: totalSplit, routePreview });
  };

  const handleCancel = () => {
    Alert.alert('Cancel Ride?', 'This may affect your reliability score.', [
      { text: 'Keep Ride', style: 'cancel' },
      {
        text: 'Cancel', style: 'destructive', onPress: async () => {
          if (rideId && user?.uid) await rideService.cancelRide(rideId, user.uid);
          setStatus('idle');
          navigation.navigate('MainApp' as any);
        },
      },
    ]);
  };

  return (
    <View style={[s.root, { paddingTop: insets.top }]}>
      {/* Background radials */}
      <View style={s.radial1} />
      <View style={s.radial2} />

      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>

        {/* Success badge */}
        <View style={s.successArea}>
          <Animated.View style={[s.ring, { transform: [{ scale: ringScale }], opacity: ringOpacity }]} />
          <Animated.View style={{ transform: [{ scale: checkScale }] }}>
            <IconCheck />
          </Animated.View>
          <Text style={s.successTitle}>Ride Confirmed</Text>
          <Text style={s.successSub}>Both riders are matched and ready</Text>
        </View>

        {/* Riders card */}
        <Animated.View style={[s.card, { opacity: cardOpacity, transform: [{ translateY: cardY }] }]}>
          <View style={s.ridersRow}>
            <View style={s.riderBox}>
              <View style={[s.avatar, s.avatarYou]}>
                <Text style={s.avatarText}>{(user?.name ?? 'Y').charAt(0).toUpperCase()}</Text>
              </View>
              <Text style={s.riderName}>{user?.name ?? 'You'}</Text>
              <View style={s.youChip}><Text style={s.youChipText}>You</Text></View>
            </View>
            <View style={s.plusWrap}>
              <View style={s.plusCircle}>
                <Text style={s.plusText}>+</Text>
              </View>
            </View>
            <View style={s.riderBox}>
              <View style={[s.avatar, s.avatarPartner]}>
                <Text style={s.avatarText}>{(rider?.name ?? 'R').charAt(0).toUpperCase()}</Text>
              </View>
              <Text style={s.riderName}>{rider?.name ?? 'Rider'}</Text>
              <View style={s.partnerChip}><Text style={s.partnerChipText}>Partner</Text></View>
            </View>
          </View>
        </Animated.View>

        {/* Route info card */}
        <Animated.View style={[s.card, { opacity: cardOpacity, transform: [{ translateY: cardY }] }]}>
          <Text style={s.cardLabel}>RIDE DETAILS</Text>
          <View style={s.infoRow}>
            <View style={s.infoIconWrap}><IconPin /></View>
            <View style={s.infoContent}>
              <Text style={s.infoKey}>Pickup</Text>
              <Text style={s.infoVal}>{resolvedPickup}</Text>
            </View>
          </View>
          <View style={s.rowDivider} />
          <View style={s.infoRow}>
            <View style={s.infoIconWrap}><IconRoute /></View>
            <View style={s.infoContent}>
              <Text style={s.infoKey}>Destination</Text>
              <Text style={s.infoVal}>{resolvedDestination ?? 'Unknown'}</Text>
            </View>
          </View>
          <View style={s.rowDivider} />
          <View style={s.infoRow}>
            <View style={s.infoIconWrap}><IconClock /></View>
            <View style={s.infoContent}>
              <Text style={s.infoKey}>ETA</Text>
              <Text style={s.infoVal}>{routePreview?.durationText ?? 'Calculating...'}</Text>
            </View>
          </View>
          <View style={s.rowDivider} />
          <View style={s.infoRow}>
            <View style={s.infoIconWrap}><IconMoney /></View>
            <View style={s.infoContent}>
              <Text style={s.infoKey}>Your fare</Text>
              <Text style={[s.infoVal, { color: C.teal }]}>৳{totalSplit} each</Text>
            </View>
            <Text style={s.infoValMuted}>Total ৳{totalFare}</Text>
          </View>
        </Animated.View>

        {/* Disclaimer */}
        <View style={s.noteCard}>
          <Text style={s.noteText}>
            Settle your fare directly with your partner and the driver. GoShareX is not responsible for payment disputes.
          </Text>
        </View>

      </ScrollView>

      {/* Action buttons */}
      <View style={[s.footer, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity
          style={[s.startBtn, (!rideId || creatingRide) && s.startBtnDisabled]}
          onPress={handleStart}
          disabled={!rideId || creatingRide}
          activeOpacity={0.85}
        >
          <IconStart />
          <Text style={s.startBtnText}>
            {creatingRide ? 'Setting up ride...' : 'Start Ride'}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={s.cancelBtn} onPress={handleCancel} activeOpacity={0.8}>
          <IconCancel />
          <Text style={s.cancelBtnText}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  radial1: { position: 'absolute', top: -60, right: -40, width: 220, height: 220, borderRadius: 110, backgroundColor: 'rgba(16,185,129,0.1)' },
  radial2: { position: 'absolute', bottom: 80, left: -60, width: 180, height: 180, borderRadius: 90, backgroundColor: 'rgba(124,111,247,0.08)' },
  scroll: { padding: 20, paddingBottom: 16 },

  successArea: { alignItems: 'center', paddingTop: 24, paddingBottom: 32, position: 'relative' },
  ring: {
    position: 'absolute', width: 120, height: 120, borderRadius: 60,
    borderWidth: 1.5, borderColor: 'rgba(16,185,129,0.5)',
  },
  successTitle: { fontSize: 26, fontWeight: '900', color: C.text, marginTop: 16, letterSpacing: -0.6 },
  successSub: { fontSize: 13, color: C.textSub, marginTop: 4 },

  card: {
    backgroundColor: C.surface, borderWidth: 1, borderColor: C.border,
    borderRadius: 24, padding: 18, marginBottom: 14,
  },
  cardLabel: { fontSize: 10, fontWeight: '800', color: C.textMuted, letterSpacing: 1.2, textTransform: 'uppercase', marginBottom: 14 },

  ridersRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  riderBox: { alignItems: 'center', gap: 6, flex: 1 },
  avatar: { width: 56, height: 56, borderRadius: 28, alignItems: 'center', justifyContent: 'center' },
  avatarYou: { backgroundColor: 'rgba(124,111,247,0.2)', borderWidth: 2, borderColor: 'rgba(124,111,247,0.5)' },
  avatarPartner: { backgroundColor: 'rgba(20,184,166,0.2)', borderWidth: 2, borderColor: 'rgba(20,184,166,0.5)' },
  avatarText: { fontSize: 22, fontWeight: '900', color: C.text },
  riderName: { fontSize: 13, fontWeight: '700', color: C.text },
  youChip: { backgroundColor: 'rgba(124,111,247,0.15)', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 2, borderWidth: 1, borderColor: 'rgba(124,111,247,0.3)' },
  youChipText: { fontSize: 9, fontWeight: '800', color: C.primary },
  partnerChip: { backgroundColor: 'rgba(20,184,166,0.1)', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 2, borderWidth: 1, borderColor: 'rgba(20,184,166,0.3)' },
  partnerChipText: { fontSize: 9, fontWeight: '800', color: C.teal },
  plusWrap: { alignItems: 'center', justifyContent: 'center' },
  plusCircle: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  plusText: { fontSize: 18, fontWeight: '800', color: C.textMuted },

  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 2 },
  infoIconWrap: { width: 30, height: 30, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.05)', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: C.border },
  infoContent: { flex: 1 },
  infoKey: { fontSize: 11, color: C.textMuted, fontWeight: '600' },
  infoVal: { fontSize: 14, fontWeight: '700', color: C.text, marginTop: 1 },
  infoValMuted: { fontSize: 12, color: C.textMuted, fontWeight: '600' },
  rowDivider: { height: 1, backgroundColor: C.border, marginVertical: 10 },

  noteCard: { backgroundColor: 'rgba(245,158,11,0.07)', borderWidth: 1, borderColor: 'rgba(245,158,11,0.18)', borderRadius: 16, padding: 12, marginBottom: 8 },
  noteText: { fontSize: 11, color: '#A0916B', lineHeight: 18, textAlign: 'center' },

  footer: { paddingHorizontal: 20, paddingTop: 12, gap: 10, borderTopWidth: 1, borderTopColor: C.border, backgroundColor: C.bg },
  startBtn: { height: 54, borderRadius: 18, backgroundColor: C.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, shadowColor: C.primary, shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.4, shadowRadius: 16, elevation: 8 },
  startBtnDisabled: { opacity: 0.5 },
  startBtnText: { fontSize: 16, fontWeight: '800', color: C.white, letterSpacing: -0.2 },
  cancelBtn: { height: 48, borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: 'rgba(244,63,94,0.08)', borderWidth: 1, borderColor: 'rgba(244,63,94,0.22)' },
  cancelBtnText: { fontSize: 14, fontWeight: '700', color: C.red },
});
