import React, { useEffect, useMemo, useState } from 'react';
import {
  Animated,
  FlatList,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Text } from 'react-native-paper';
import { useBottomTabBarHeight } from '@react-navigation/bottom-tabs';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { collection, onSnapshot, orderBy, query, where } from 'firebase/firestore';
import Svg, { Circle, Defs, LinearGradient, Path, Rect, Stop, G } from 'react-native-svg';

import { db } from '@/config/firebase.config';
import PremiumScreen from '@/components/common/PremiumScreen';
import { premiumTheme } from '@/design/premium';
import { useAuthStore } from '@/store/authStore';
import { useNavigation } from '@react-navigation/native';
import chatService from '@/services/firebase/chatService';

// ─── Design tokens — Finova glossy Apple vibes ────────────────────────────────
const C = {
  bg: premiumTheme.bg,
  surface: 'rgba(255,255,255,0.055)',
  surfaceHover: 'rgba(255,255,255,0.09)',
  glass: 'rgba(255,255,255,0.04)',
  border: 'rgba(255,255,255,0.09)',
  borderStrong: 'rgba(255,255,255,0.15)',
  primary: premiumTheme.primary,
  primaryGlow: 'rgba(124,111,247,0.35)',
  teal: premiumTheme.teal,
  tealGlow: 'rgba(20,184,166,0.3)',
  amber: premiumTheme.amber,
  red: premiumTheme.rose,
  green: premiumTheme.green,
  text: premiumTheme.text,
  textSub: premiumTheme.textMuted,
  textMuted: '#343D55',
  white: '#FFFFFF',
  purple: premiumTheme.primaryBright,
};

interface ChatItem {
  id: string;
  participants: string[];
  participantNames: Record<string, string>;
  participantAliases?: Record<string, string>;
  destination: string;
  fare: number;
  mode?: 'ride' | 'anonymous_1v1' | 'anonymous_group';
  anonymous?: boolean;
  expiresAt?: number;
  searching?: boolean;
  lastMessage: string;
  lastMessageTime: number;
  dealConfirmed: Record<string, boolean>;
  historyCleared?: boolean;
}

const minutesLeft = (expiresAt?: number) => {
  if (!expiresAt) return null;
  return Math.max(0, Math.ceil((expiresAt - Date.now()) / 60000));
};

// ─── SVG Icons ────────────────────────────────────────────────────────────────
const IconSearch = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
    <Circle cx="11" cy="11" r="8" stroke={C.textSub} strokeWidth="1.8" />
    <Path d="M21 21l-4.35-4.35" stroke={C.textSub} strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);

const IconGhost = () => (
  <Svg width={22} height={22} viewBox="0 0 24 24" fill="none">
    <Path d="M9 10h.01M15 10h.01M12 2a9 9 0 00-9 9v10l3-3 2.5 2.5L11 18l1 3 1-3 2.5 2.5L19 21l3 3V11a9 9 0 00-9-9z" stroke={C.white} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const IconGroup = () => (
  <Svg width={22} height={22} viewBox="0 0 24 24" fill="none">
    <Circle cx="9" cy="7" r="4" stroke={C.white} strokeWidth="1.7" />
    <Path d="M3 20c0-4 2.7-7 6-7" stroke={C.white} strokeWidth="1.7" strokeLinecap="round" />
    <Circle cx="17" cy="9" r="3" stroke={C.white} strokeWidth="1.7" />
    <Path d="M21 20c0-3-1.8-5-4-5" stroke={C.white} strokeWidth="1.7" strokeLinecap="round" />
  </Svg>
);

const IconMessage = () => (
  <Svg width={20} height={20} viewBox="0 0 24 24" fill="none">
    <Path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" stroke={C.white} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const IconChevron = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
    <Path d="M9 18l6-6-6-6" stroke={C.textMuted} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const IconTimer = () => (
  <Svg width={12} height={12} viewBox="0 0 24 24" fill="none">
    <Circle cx="12" cy="12" r="9" stroke={C.amber} strokeWidth="1.8" />
    <Path d="M12 7v5l3 3" stroke={C.amber} strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);

const IconShield = () => (
  <Svg width={14} height={14} viewBox="0 0 24 24" fill="none">
    <Path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke={C.purple} strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);

// ─── Animated live dot ────────────────────────────────────────────────────────
const PulseDot = ({ color = C.green }: { color?: string }) => {
  const anim = React.useRef(new Animated.Value(1)).current;
  React.useEffect(() => {
    Animated.loop(Animated.sequence([
      Animated.timing(anim, { toValue: 0.25, duration: 800, useNativeDriver: true }),
      Animated.timing(anim, { toValue: 1, duration: 800, useNativeDriver: true }),
    ])).start();
  }, []);
  return <Animated.View style={{ width: 7, height: 7, borderRadius: 3.5, backgroundColor: color, opacity: anim }} />;
};

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function ChatListScreen() {
  const insets = useSafeAreaInsets();
  const tabBarHeight = useBottomTabBarHeight();
  const { user } = useAuthStore();
  const navigation = useNavigation<any>();
  const [chats, setChats] = useState<ChatItem[]>([]);
  const [searchingMode, setSearchingMode] = useState<'anonymous_1v1' | 'anonymous_group' | null>(null);
  const [queryText, setQueryText] = useState('');

  useEffect(() => {
    if (!user?.uid) return;
    const q = query(
      collection(db, 'chats'),
      where('participants', 'array-contains', user.uid),
      orderBy('lastMessageTime', 'desc')
    );
    return onSnapshot(q, (snap) => {
      setChats(snap.docs.map((d) => ({ id: d.id, ...d.data() } as ChatItem)));
    });
  }, [user?.uid]);

  // ── Visibility rules:
  //   • 1v1 anonymous: NEVER show in list (hidden always)
  //   • Group anonymous: show while active (expiresAt > now)
  //   • Ride chat: always show
  const visibleChats = useMemo(() => {
    return chats.filter((item) => {
      if (item.mode === 'anonymous_1v1') return false; // always hidden
      if (item.anonymous && item.mode === 'anonymous_group') {
        return (item.expiresAt ?? 0) > Date.now(); // only while live
      }
      return true; // ride chats always visible
    });
  }, [chats]);

  const filteredChats = useMemo(() => {
    const norm = queryText.trim().toLowerCase();
    if (!norm) return visibleChats;
    return visibleChats.filter((item) => {
      const otherUid = item.participants.find((p) => p !== user?.uid) ?? '';
      const name = item.anonymous
        ? 'anonymous group'
        : item.participantNames[otherUid] ?? item.destination;
      return `${name} ${item.destination} ${item.lastMessage}`.toLowerCase().includes(norm);
    });
  }, [queryText, visibleChats, user?.uid]);

  const stats = useMemo(() => ({
    liveGroup: chats.filter(c => c.mode === 'anonymous_group' && (c.expiresAt ?? 0) > Date.now()).length,
    rideChats: chats.filter(c => !c.anonymous).length,
    total: visibleChats.length,
  }), [chats, visibleChats]);

  const handleStartAnonymous = async (mode: 'anonymous_1v1' | 'anonymous_group') => {
    if (!user?.uid) return;
    try {
      setSearchingMode(mode);
      const chatId = mode === 'anonymous_1v1'
        ? await chatService.startAnonymousOneToOne(user.uid)
        : await chatService.startAnonymousGroup(user.uid);
      navigation.navigate('Chat', {
        chatId,
        anonymousMode: mode,
        partnerName: mode === 'anonymous_1v1' ? 'Anonymous 1:1' : 'Anonymous Group',
      });
    } finally {
      setSearchingMode(null);
    }
  };

  const renderChat = ({ item }: { item: ChatItem }) => {
    const otherUid = item.participants.find((p) => p !== user?.uid) ?? '';
    const otherName = item.anonymous
      ? `Anonymous Group (${item.participants.length})`
      : item.participantNames[otherUid] ?? 'Rider';
    const bothConfirmed = Object.values(item.dealConfirmed ?? {}).every(Boolean);
    const timeStr = item.lastMessageTime
      ? new Date(item.lastMessageTime).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
      : '';
    const mins = minutesLeft(item.expiresAt);
    const initials = otherName.charAt(0).toUpperCase();

    return (
      <TouchableOpacity
        style={s.chatCard}
        activeOpacity={0.82}
        onPress={() => navigation.navigate('Chat', {
          rider: item.anonymous ? undefined : {
            userId: otherUid, name: otherName,
            destination: item.destination, rating: 5,
            distance: 0, badge: 'Rider', lat: 0, lng: 0, isMatch: true,
          },
          chatId: item.id,
          anonymousMode: item.anonymous ? item.mode : undefined,
          partnerName: otherName,
        })}
      >
        {/* Avatar */}
        <View style={[s.avatar, item.anonymous ? s.avatarGroup : bothConfirmed ? s.avatarDeal : s.avatarRide]}>
          <Text style={s.avatarText}>{initials}</Text>
          {item.anonymous && (
            <View style={s.avatarLiveDot}>
              <PulseDot color={C.green} />
            </View>
          )}
        </View>

        {/* Content */}
        <View style={s.chatContent}>
          <View style={s.chatTopRow}>
            <Text style={s.chatName} numberOfLines={1}>{otherName}</Text>
            <Text style={s.chatTime}>{timeStr}</Text>
          </View>

          {/* Chips */}
          <View style={s.chipsRow}>
            <View style={[s.chip, item.anonymous ? s.chipGroup : bothConfirmed ? s.chipDeal : s.chipRide]}>
              <Text style={[s.chipText, item.anonymous ? s.chipTextGroup : bothConfirmed ? s.chipTextDeal : s.chipTextRide]}>
                {item.anonymous ? 'Anonymous Group' : bothConfirmed ? 'Deal Confirmed' : 'Ride Chat'}
              </Text>
            </View>
            {mins !== null && (
              <View style={s.chipTimer}>
                <IconTimer />
                <Text style={s.chipTimerText}>{mins}m left</Text>
              </View>
            )}
          </View>

          <Text style={s.chatRoute} numberOfLines={1}>
            {item.anonymous
              ? `${item.participants.length} members in room`
              : `Route: ${item.destination}`}
          </Text>
          <Text style={s.chatLastMsg} numberOfLines={1}>
            {item.lastMessage || (item.anonymous ? 'Anonymous group started' : 'Ride chat started')}
          </Text>
        </View>

        <IconChevron />
      </TouchableOpacity>
    );
  };

  return (
    <PremiumScreen>
    <View style={[s.root, { paddingTop: insets.top }]}>
      {/* Background radials */}
      <View style={s.radial1} />
      <View style={s.radial2} />

      {/* Hero header */}
      <View style={s.hero}>
        <View style={s.heroTop}>
          <View>
            <Text style={s.heroLabel}>CONVERSATIONS</Text>
            <Text style={s.heroTitle}>Chat Rooms</Text>
          </View>
          <View style={s.liveBadge}>
            <PulseDot />
            <Text style={s.liveBadgeText}>LIVE</Text>
          </View>
        </View>

        {/* Stats */}
        <View style={s.statsRow}>
          <View style={s.statCard}>
            <Text style={s.statVal}>{stats.liveGroup}</Text>
            <Text style={s.statLbl}>Live groups</Text>
          </View>
          <View style={[s.statCard, s.statCardMid]}>
            <Text style={s.statVal}>{stats.rideChats}</Text>
            <Text style={s.statLbl}>Ride chats</Text>
          </View>
          <View style={s.statCard}>
            <Text style={s.statVal}>{stats.total}</Text>
            <Text style={s.statLbl}>Visible rooms</Text>
          </View>
        </View>
      </View>

      {/* Anonymous match buttons */}
      <View style={s.matchSection}>
        <TouchableOpacity
          style={s.matchBtn1}
          onPress={() => handleStartAnonymous('anonymous_1v1')}
          disabled={searchingMode !== null}
          activeOpacity={0.85}
        >
          <View style={s.matchBtnIcon}><IconGhost /></View>
          <View style={{ flex: 1 }}>
            <Text style={s.matchBtnTitle}>
              {searchingMode === 'anonymous_1v1' ? 'Finding match...' : 'Anonymous 1:1'}
            </Text>
            <Text style={s.matchBtnSub}>Private · 15 min · History auto-deleted</Text>
          </View>
          <View style={s.matchBtnBadge}>
            <IconShield />
            <Text style={s.matchBtnBadgeText}>PRIVATE</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          style={s.matchBtn2}
          onPress={() => handleStartAnonymous('anonymous_group')}
          disabled={searchingMode !== null}
          activeOpacity={0.85}
        >
          <View style={[s.matchBtnIcon, { backgroundColor: 'rgba(20,184,166,0.18)' }]}><IconGroup /></View>
          <View style={{ flex: 1 }}>
            <Text style={[s.matchBtnTitle, { color: '#5EEAD4' }]}>
              {searchingMode === 'anonymous_group' ? 'Joining room...' : 'Anonymous Group'}
            </Text>
            <Text style={[s.matchBtnSub, { color: '#4B7A74' }]}>2–10 people · 15 min · Visible in list</Text>
          </View>
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={s.searchBar}>
        <IconSearch />
        <TextInput
          style={s.searchInput}
          value={queryText}
          onChangeText={setQueryText}
          placeholder="Search rooms, routes..."
          placeholderTextColor={C.textMuted}
        />
      </View>

      {/* List header */}
      <View style={s.listHead}>
        <Text style={s.listHeadTitle}>Active Conversations</Text>
        <Text style={s.listHeadSub}>{filteredChats.length} rooms</Text>
      </View>

      {/* Chat list */}
      <FlatList
        data={filteredChats}
        keyExtractor={(c) => c.id}
        renderItem={renderChat}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: tabBarHeight + 20, gap: 10 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={s.empty}>
            <View style={s.emptyOrb}>
              <IconMessage />
            </View>
            <Text style={s.emptyTitle}>No active conversations</Text>
            <Text style={s.emptySub}>
              Start an anonymous 1:1 or group room, or match a rider from the home screen.
            </Text>
          </View>
        }
      />
    </View>
    </PremiumScreen>
  );
}

// ─── Styles ──────────────────────────────────────────────────────────────────
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  radial1: {
    position: 'absolute', top: -60, right: -40,
    width: 240, height: 240, borderRadius: 120,
    backgroundColor: 'rgba(124,111,247,0.12)',
  },
  radial2: {
    position: 'absolute', top: 160, left: -60,
    width: 180, height: 180, borderRadius: 90,
    backgroundColor: 'rgba(20,184,166,0.08)',
  },

  // Hero
  hero: {
    marginHorizontal: 16, marginTop: 8, marginBottom: 14,
    backgroundColor: 'rgba(124,111,247,0.08)',
    borderWidth: 1, borderColor: 'rgba(124,111,247,0.2)',
    borderRadius: 24, padding: 18,
  },
  heroTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 },
  heroLabel: { fontSize: 10, fontWeight: '800', color: C.purple, letterSpacing: 1.5, textTransform: 'uppercase' },
  heroTitle: { fontSize: 22, fontWeight: '900', color: C.text, marginTop: 4, letterSpacing: -0.5 },
  liveBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: 'rgba(16,185,129,0.12)',
    borderRadius: 20, paddingHorizontal: 10, paddingVertical: 6,
    borderWidth: 1, borderColor: 'rgba(16,185,129,0.25)',
  },
  liveBadgeText: { fontSize: 9, fontWeight: '800', color: C.green, letterSpacing: 1 },
  statsRow: { flexDirection: 'row', gap: 10 },
  statCard: {
    flex: 1, backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16, paddingVertical: 10, paddingHorizontal: 12,
    borderWidth: 1, borderColor: C.border,
  },
  statCardMid: { borderColor: 'rgba(124,111,247,0.3)', backgroundColor: 'rgba(124,111,247,0.07)' },
  statVal: { fontSize: 20, fontWeight: '900', color: C.text },
  statLbl: { fontSize: 10, color: C.textSub, marginTop: 3, fontWeight: '600' },

  // Match buttons
  matchSection: { paddingHorizontal: 16, gap: 10, marginBottom: 12 },
  matchBtn1: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: 'rgba(124,111,247,0.12)',
    borderWidth: 1, borderColor: 'rgba(124,111,247,0.25)',
    borderRadius: 20, padding: 14,
  },
  matchBtn2: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: 'rgba(20,184,166,0.07)',
    borderWidth: 1, borderColor: 'rgba(20,184,166,0.2)',
    borderRadius: 20, padding: 14,
  },
  matchBtnIcon: {
    width: 44, height: 44, borderRadius: 14,
    backgroundColor: 'rgba(124,111,247,0.18)',
    alignItems: 'center', justifyContent: 'center',
  },
  matchBtnTitle: { fontSize: 15, fontWeight: '800', color: C.text },
  matchBtnSub: { fontSize: 11, color: C.textSub, marginTop: 2 },
  matchBtnBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: 'rgba(167,139,250,0.12)',
    borderRadius: 8, paddingHorizontal: 7, paddingVertical: 3,
    borderWidth: 1, borderColor: 'rgba(167,139,250,0.25)',
  },
  matchBtnBadgeText: { fontSize: 8, fontWeight: '800', color: C.purple, letterSpacing: 0.5 },

  // Search
  searchBar: {
    marginHorizontal: 16, marginBottom: 12,
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: C.surface, borderRadius: 16,
    borderWidth: 1, borderColor: C.border,
    paddingHorizontal: 14, paddingVertical: 4,
  },
  searchInput: { flex: 1, fontSize: 14, color: C.text, paddingVertical: 10 },

  // List header
  listHead: {
    paddingHorizontal: 16, marginBottom: 10,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline',
  },
  listHeadTitle: { fontSize: 16, fontWeight: '900', color: C.text },
  listHeadSub: { fontSize: 12, color: C.textSub },

  // Chat card
  chatCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: C.surface,
    borderWidth: 1, borderColor: C.border,
    borderRadius: 22, padding: 14,
  },
  avatar: {
    width: 48, height: 48, borderRadius: 24,
    alignItems: 'center', justifyContent: 'center',
    position: 'relative',
  },
  avatarRide: { backgroundColor: 'rgba(124,111,247,0.2)', borderWidth: 1.5, borderColor: 'rgba(124,111,247,0.4)' },
  avatarGroup: { backgroundColor: 'rgba(20,184,166,0.2)', borderWidth: 1.5, borderColor: 'rgba(20,184,166,0.4)' },
  avatarDeal: { backgroundColor: 'rgba(16,185,129,0.2)', borderWidth: 1.5, borderColor: 'rgba(16,185,129,0.4)' },
  avatarText: { fontSize: 18, fontWeight: '900', color: C.text },
  avatarLiveDot: { position: 'absolute', bottom: 1, right: 1 },
  chatContent: { flex: 1 },
  chatTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  chatName: { fontSize: 14, fontWeight: '800', color: C.text, flex: 1, paddingRight: 8 },
  chatTime: { fontSize: 11, color: C.textMuted },
  chipsRow: { flexDirection: 'row', gap: 6, flexWrap: 'wrap', marginTop: 5 },
  chip: { borderRadius: 20, paddingHorizontal: 9, paddingVertical: 3 },
  chipRide: { backgroundColor: 'rgba(124,111,247,0.12)', borderWidth: 1, borderColor: 'rgba(124,111,247,0.25)' },
  chipGroup: { backgroundColor: 'rgba(20,184,166,0.1)', borderWidth: 1, borderColor: 'rgba(20,184,166,0.25)' },
  chipDeal: { backgroundColor: 'rgba(16,185,129,0.1)', borderWidth: 1, borderColor: 'rgba(16,185,129,0.25)' },
  chipText: { fontSize: 10, fontWeight: '700' },
  chipTextRide: { color: C.purple },
  chipTextGroup: { color: C.teal },
  chipTextDeal: { color: C.green },
  chipTimer: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: 'rgba(245,158,11,0.1)',
    borderRadius: 20, paddingHorizontal: 8, paddingVertical: 3,
    borderWidth: 1, borderColor: 'rgba(245,158,11,0.25)',
  },
  chipTimerText: { fontSize: 10, fontWeight: '700', color: C.amber },
  chatRoute: { fontSize: 11, color: C.textSub, marginTop: 5 },
  chatLastMsg: { fontSize: 12, color: C.textMuted, marginTop: 2 },

  // Empty
  empty: { alignItems: 'center', marginTop: 60, paddingHorizontal: 32 },
  emptyOrb: {
    width: 68, height: 68, borderRadius: 34,
    backgroundColor: 'rgba(124,111,247,0.12)',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: 'rgba(124,111,247,0.25)',
    marginBottom: 16,
  },
  emptyTitle: { fontSize: 17, fontWeight: '900', color: C.text, marginBottom: 8 },
  emptySub: { fontSize: 13, color: C.textSub, textAlign: 'center', lineHeight: 20 },
});
