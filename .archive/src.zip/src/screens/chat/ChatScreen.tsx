﻿import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
  Animated,
} from 'react-native';
import { Text } from 'react-native-paper';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Circle, Defs, LinearGradient, Path, Rect, Stop } from 'react-native-svg';

import { useAuthStore } from '@/store/authStore';
import { useRideStore } from '@/store/rideStore';
import chatService, { Chat, Message } from '@/services/firebase/chatService';
import { getFare } from '@/constants/fareTable';
import { sendRideRequest } from '@/services/notifications/fcmService';

// â”€â”€â”€ Design tokens â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const C = {
  bg: '#080C14',
  surface: 'rgba(255,255,255,0.05)',
  surfaceStrong: 'rgba(255,255,255,0.08)',
  border: 'rgba(255,255,255,0.1)',
  primary: '#6366F1',
  teal: '#14B8A6',
  text: '#E2E8F0',
  textSub: '#6E7E99',
  textMuted: '#64748B',
  white: '#FFFFFF',
  amber: '#F59E0B',
  red: '#F43F5E',
  green: '#10B981',
};

const QUICK_REPLIES = [
  { id: 'hello', text: 'Hello' },
  { id: 'coming', text: 'On my way' },
  { id: 'wait', text: 'Please wait' },
  { id: 'where', text: 'Where are you?' },
  { id: 'cancel', text: 'Need to cancel' },
];

const formatCountdown = (ms: number) => {
  const s = Math.max(0, Math.floor(ms / 1000));
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
};

// â”€â”€â”€ SVG Icons â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const IconSend = () => (
  <Svg width={20} height={20} viewBox="0 0 24 24" fill="none">
    <Path d="M22 2L11 13" stroke={C.white} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Path d="M22 2L15 22L11 13L2 9L22 2Z" stroke={C.white} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const IconBack = () => (
  <Svg width={20} height={20} viewBox="0 0 24 24" fill="none">
    <Path d="M19 12H5M5 12L12 19M5 12L12 5" stroke={C.text} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const IconChat = () => (
  <Svg width={20} height={20} viewBox="0 0 24 24" fill="none">
    <Path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" stroke={C.text} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const IconShield = () => (
  <Svg width={14} height={14} viewBox="0 0 24 24" fill="none">
    <Path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke={C.amber} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const IconCheck = () => (
  <Svg width={14} height={14} viewBox="0 0 24 24" fill="none">
    <Path d="M20 6L9 17L4 12" stroke={C.green} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const IconHandshake = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M9 11l3 3L22 4" stroke={C.white} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11" stroke={C.white} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

// â”€â”€â”€ Avatar â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const MiniAvatar = ({ label, gradient }: { label: string; gradient?: boolean }) => (
  <View style={[av.wrap, gradient && av.gradient]}>
    <Text style={av.text}>{label.charAt(0).toUpperCase()}</Text>
  </View>
);
const av = StyleSheet.create({
  wrap: { width: 30, height: 30, borderRadius: 15, backgroundColor: 'rgba(99,102,241,0.25)', alignItems: 'center', justifyContent: 'center' },
  gradient: { backgroundColor: 'rgba(20,184,166,0.25)' },
  text: { fontSize: 12, fontWeight: '800', color: C.text },
});

// â”€â”€â”€ Live dot â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const LiveDot = ({ color = C.green }: { color?: string }) => {
  const anim = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.loop(Animated.sequence([
      Animated.timing(anim, { toValue: 0.3, duration: 700, useNativeDriver: true }),
      Animated.timing(anim, { toValue: 1, duration: 700, useNativeDriver: true }),
    ])).start();
  }, []);
  return <Animated.View style={{ width: 7, height: 7, borderRadius: 3.5, backgroundColor: color, opacity: anim }} />;
};

// â”€â”€â”€ Main Screen â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export default function ChatScreen() {
  const route = useRoute<any>();
  const navigation = useNavigation<any>();
  const insets = useSafeAreaInsets();
  const { user } = useAuthStore();
  const { destination, pickupPoint } = useRideStore();

  const rider = route.params?.rider;
  const requestedAnonymousMode = route.params?.anonymousMode as 'anonymous_1v1' | 'anonymous_group' | undefined;
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [chatId, setChatId] = useState<string | null>(route.params?.chatId ?? null);
  const [chatMeta, setChatMeta] = useState<Partial<Chat> | null>(null);
  const [dealConfirmed, setDealConfirmed] = useState(false);
  const [myDealPressed, setMyDealPressed] = useState(false);
  const [remainingMs, setRemainingMs] = useState<number | null>(null);
  const [historyDeleted, setHistoryDeleted] = useState(false);
  const listRef = useRef<FlatList>(null);

  const fare = getFare(pickupPoint ?? 'main_gate', destination ?? 'kuril');
  const splitFare = Math.ceil(fare / 2);
  const isAnonymousRoom = !!chatMeta?.anonymous || !!requestedAnonymousMode;
  const isAnonymousGroup = chatMeta?.mode === 'anonymous_group' || requestedAnonymousMode === 'anonymous_group';
  const isAnonymous1v1 = (chatMeta?.mode === 'anonymous_1v1' || requestedAnonymousMode === 'anonymous_1v1') && !isAnonymousGroup;
  const participantCount = chatMeta?.participants?.length ?? 0;
  const minParticipants = chatMeta?.minParticipants ?? 2;
  const isWaiting = isAnonymousRoom && participantCount < minParticipants;
  const roomExpired = (remainingMs ?? 1) <= 0;

  const countdownProgress = useMemo(() => {
    if (!chatMeta?.expiresAt) return 0;
    const startedAt = chatMeta.expiresAt - 15 * 60 * 1000;
    return Math.max(0, Math.min(1, (Date.now() - startedAt) / (15 * 60 * 1000)));
  }, [chatMeta?.expiresAt, remainingMs]);

  const title = useMemo(() => {
    if (isAnonymousGroup) return 'Anonymous Group';
    if (isAnonymous1v1) return 'Anonymous 1:1';
    return rider?.name ?? route.params?.partnerName ?? 'Rider';
  }, [isAnonymousGroup, isAnonymous1v1, rider?.name, route.params?.partnerName]);

  // Init chat
  useEffect(() => {
    if (!user) return;
    if (route.params?.chatId) { setChatId(route.params.chatId); return; }
    if (!rider) return;
    const init = async () => {
      const id = await chatService.getOrCreateChat(
        user.uid, user.name ?? 'You',
        rider.userId, rider.name,
        destination ?? rider.destination, fare
      );
      setChatId(id);
    };
    void init();
  }, [destination, fare, rider, route.params?.chatId, user]);

  // Real-time listeners
  useEffect(() => {
    if (!chatId) return;
    const unsub1 = chatService.listenToMessages(chatId, setMessages);
    const unsub2 = chatService.listenToChat(chatId, (chat) => {
      setChatMeta(chat);
      if (!chat.anonymous && chat.dealConfirmed) {
        setDealConfirmed(Object.values(chat.dealConfirmed).every(Boolean));
      }
    });
    return () => { unsub1(); unsub2(); };
  }, [chatId]);

  // Countdown timer
  useEffect(() => {
    if (!chatMeta?.expiresAt) { setRemainingMs(null); return; }
    const update = () => setRemainingMs(chatMeta.expiresAt! - Date.now());
    update();
    const timer = setInterval(update, 1000);
    return () => clearInterval(timer);
  }, [chatMeta?.expiresAt]);

  // Auto-delete 1v1 history and redirect on room expiry
  useEffect(() => {
    if (!isAnonymousRoom || !roomExpired || historyDeleted) return;
    setHistoryDeleted(true);

    const cleanup = async () => {
      if (chatId) {
        if (isAnonymous1v1) {
          // 1v1: delete all messages (privacy)
          await chatService.deleteOneToOneHistory(chatId);
        } else {
          // group: delete entire room after expiry
          await chatService.deleteAnonymousRoom(chatId);
        }
      }
    };
    void cleanup();

    const t = setTimeout(() => {
      navigation.navigate('MainApp' as any);
    }, 2000);
    return () => clearTimeout(t);
  }, [isAnonymousRoom, roomExpired, historyDeleted, chatId, isAnonymous1v1]);

  const sendMsg = async (msgText?: string) => {
    const content = msgText ?? text.trim();
    if (!content || !chatId || !user) return;
    if (roomExpired) { Alert.alert('Session ended', 'This chat session has expired.'); return; }
    setText('');
    const senderName = isAnonymousRoom
      ? chatMeta?.participantAliases?.[user.uid] ?? 'Anonymous'
      : user.name ?? 'You';
    await chatService.sendMessage(chatId, user.uid, senderName, content);
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
  };

  const handleDealConfirm = async () => {
    if (!chatId || !user || isAnonymousRoom) return;
    setMyDealPressed(true);

    // Send ride request notification to the other rider
    if (rider?.userId) {
      sendRideRequest(
        rider.userId,
        user.name ?? 'A rider',
        chatMeta?.destination ?? destination ?? 'Unknown',
        fare ?? 0,
        chatId,
      ).catch(e => console.warn('[ChatScreen] sendRideRequest failed:', e));
    }

    const bothConfirmed = await chatService.confirmDeal(chatId, user.uid);
    if (bothConfirmed) {
      navigation.navigate('RideConfirmed', { rider, chatId, fare, splitFare });
    } else {
      Alert.alert('Pending', `Waiting for ${rider?.name ?? 'the other rider'} to confirm.`);
    }
  };

  const renderMessage = ({ item }: { item: Message }) => {
    if (item.type === 'system') {
      return (
        <View style={m.systemRow}>
          <View style={m.systemPill}>
            <Text style={m.systemText}>{item.text}</Text>
          </View>
        </View>
      );
    }
    const isMe = item.senderId === user?.uid;
    const label = isAnonymousRoom
      ? chatMeta?.participantAliases?.[item.senderId] ?? item.senderName ?? 'Anonymous'
      : item.senderName;

    return (
      <View style={[m.row, isMe && m.rowMe]}>
        {!isMe && <MiniAvatar label={label ?? 'A'} gradient={isAnonymousRoom} />}
        <View style={[m.bubble, isMe ? m.bubbleMe : m.bubbleThem]}>
          {!isMe && <Text style={m.senderLabel}>{label}</Text>}
          <Text style={[m.bubbleText, isMe && m.bubbleTextMe]}>{item.text}</Text>
        </View>
      </View>
    );
  };

  return (
    <View style={s.root}>
      {/* Header */}
      <View style={[s.header, { paddingTop: insets.top + 10 }]}>
        <TouchableOpacity style={s.headerBtn} onPress={() => navigation.goBack()} activeOpacity={0.7}>
          <IconBack />
        </TouchableOpacity>
        <View style={s.headerCenter}>
          <View style={s.headerTitleRow}>
            {isAnonymousRoom && <LiveDot color={roomExpired ? C.red : C.green} />}
            <Text style={s.headerTitle} numberOfLines={1}>{title}</Text>
          </View>
          <Text style={s.headerSub} numberOfLines={1}>
            {isAnonymousRoom
              ? roomExpired ? 'Session ended' : `Ends in ${formatCountdown(remainingMs ?? 0)}`
              : destination ?? rider?.destination ?? 'Ride Chat'}
          </Text>
        </View>
        <TouchableOpacity
          style={s.headerBtn}
          onPress={() => navigation.navigate('MainApp' as any)}
          activeOpacity={0.7}
        >
          <IconChat />
        </TouchableOpacity>
      </View>

      {/* Info banner */}
      {isAnonymousRoom ? (
        <View style={s.anonBanner}>
          <View style={s.anonBannerRow}>
            <View style={s.anonBannerLeft}>
              <View style={s.anonChip}>
                <IconShield />
                <Text style={s.anonChipText}>
                  {isAnonymousGroup ? `Group | ${participantCount}/10 members` : 'Private 1:1'}
                </Text>
              </View>
              <Text style={s.anonNote}>
                {isWaiting ? 'Waiting for another person to join...' : 'Identities are hidden. Messages auto-delete after session.'}
              </Text>
            </View>
            <View style={s.timerCircle}>
              <Text style={s.timerCircleNum}>{formatCountdown(remainingMs ?? 0)}</Text>
              <Text style={s.timerCircleLabel}>left</Text>
            </View>
          </View>
          <View style={s.timerTrack}>
            <View style={[s.timerFill, { width: `${countdownProgress * 100}%` as any }]} />
          </View>
        </View>
      ) : (
        <View style={s.fareBanner}>
          <Text style={s.fareBannerLabel}>Fare split</Text>
          <Text style={s.fareBannerFare}>BDT {fare} / 2 = <Text style={s.fareBannerSplit}>BDT {splitFare} each</Text></Text>
        </View>
      )}

      {/* Messages */}
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={insets.top + 60}
      >
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(m) => m.id}
          renderItem={renderMessage}
          contentContainerStyle={{ padding: 16, gap: 10 }}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
          ListEmptyComponent={
            <View style={s.emptyMsgs}>
              <Text style={s.emptyMsgsText}>
                {isWaiting ? 'Waiting for another user to join...' : 'No messages yet. Say hello!'}
              </Text>
            </View>
          }
        />

        {/* Quick replies */}
        <View style={s.quickRow}>
          {QUICK_REPLIES.map((qr) => (
            <TouchableOpacity
              key={qr.id}
              style={[s.qrBtn, roomExpired && s.qrBtnDisabled]}
              onPress={() => { void sendMsg(qr.text); }}
              disabled={roomExpired}
              activeOpacity={0.75}
            >
              <Text style={s.qrText}>{qr.text}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Input row */}
        <View style={[s.inputRow, { paddingBottom: insets.bottom + 10 }]}>
          <TextInput
            style={s.input}
            value={text}
            onChangeText={setText}
            placeholder={roomExpired ? 'Session has ended' : 'Write a message...'}
            placeholderTextColor={C.textMuted}
            multiline
            maxLength={300}
            editable={!roomExpired}
          />
          <TouchableOpacity
            style={[s.sendBtn, (roomExpired || !text.trim()) && s.sendBtnDisabled]}
            onPress={() => { void sendMsg(); }}
            disabled={roomExpired || !text.trim()}
            activeOpacity={0.8}
          >
            <IconSend />
          </TouchableOpacity>
        </View>

        {/* Deal confirm (ride chats only) */}
        {!isAnonymousRoom && !dealConfirmed && (
          <TouchableOpacity
            style={[s.dealBtn, myDealPressed && s.dealBtnPending]}
            onPress={handleDealConfirm}
            disabled={myDealPressed}
            activeOpacity={0.85}
          >
            <IconHandshake />
            <Text style={s.dealBtnText}>
              {myDealPressed ? 'Waiting for partner confirmation...' : 'Confirm Deal | BDT ' + splitFare + ' each'}
            </Text>
          </TouchableOpacity>
        )}
        {!isAnonymousRoom && dealConfirmed && (
          <View style={s.dealConfirmedRow}>
            <IconCheck />
            <Text style={s.dealConfirmedText}>Deal confirmed | proceeding to ride</Text>
          </View>
        )}

        {/* Expired banner */}
        {isAnonymousRoom && roomExpired && (
          <View style={s.expiredBanner}>
            <Text style={s.expiredTitle}>Session ended</Text>
            <Text style={s.expiredSub}>
              {isAnonymous1v1 ? 'Chat history has been deleted. Returning to lobby...' : 'Anonymous group session closed. Returning to lobby...'}
            </Text>
          </View>
        )}
      </KeyboardAvoidingView>
    </View>
  );
}

// â”€â”€â”€ Styles â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 14, paddingBottom: 12,
    borderBottomWidth: 1, borderBottomColor: C.border,
    backgroundColor: C.bg,
  },
  headerBtn: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  headerCenter: { flex: 1, alignItems: 'center', paddingHorizontal: 8 },
  headerTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  headerTitle: { fontSize: 16, fontWeight: '800', color: C.text },
  headerSub: { fontSize: 11, color: C.textSub, marginTop: 2 },

  anonBanner: {
    backgroundColor: 'rgba(245,158,11,0.08)',
    borderBottomWidth: 1, borderBottomColor: 'rgba(245,158,11,0.2)',
    paddingHorizontal: 16, paddingVertical: 12,
  },
  anonBannerRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 },
  anonBannerLeft: { flex: 1, gap: 4 },
  anonChip: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(245,158,11,0.12)',
    borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4,
    borderWidth: 1, borderColor: 'rgba(245,158,11,0.25)',
  },
  anonChipText: { fontSize: 11, fontWeight: '700', color: C.amber },
  anonNote: { fontSize: 11, color: '#A0916B', lineHeight: 16 },
  timerCircle: {
    width: 54, height: 54, borderRadius: 27,
    backgroundColor: 'rgba(245,158,11,0.1)',
    borderWidth: 1.5, borderColor: 'rgba(245,158,11,0.3)',
    alignItems: 'center', justifyContent: 'center',
  },
  timerCircleNum: { fontSize: 12, fontWeight: '800', color: C.amber },
  timerCircleLabel: { fontSize: 8, color: C.amber, fontWeight: '600', marginTop: -2 },
  timerTrack: { height: 3, backgroundColor: 'rgba(245,158,11,0.15)', borderRadius: 2, overflow: 'hidden' },
  timerFill: { height: '100%', backgroundColor: C.amber, borderRadius: 2 },

  fareBanner: {
    backgroundColor: 'rgba(99,102,241,0.08)',
    borderBottomWidth: 1, borderBottomColor: 'rgba(99,102,241,0.2)',
    paddingHorizontal: 16, paddingVertical: 10,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
  },
  fareBannerLabel: { fontSize: 12, color: C.textSub, fontWeight: '600' },
  fareBannerFare: { fontSize: 13, color: C.text, fontWeight: '600' },
  fareBannerSplit: { color: C.teal, fontWeight: '800' },

  emptyMsgs: { alignItems: 'center', marginTop: 60 },
  emptyMsgsText: { fontSize: 13, color: C.textSub, textAlign: 'center', lineHeight: 20 },

  quickRow: {
    flexDirection: 'row', flexWrap: 'wrap', gap: 6,
    paddingHorizontal: 12, paddingVertical: 8,
    backgroundColor: C.bg, borderTopWidth: 1, borderTopColor: C.border,
  },
  qrBtn: {
    backgroundColor: C.surface, borderRadius: 16,
    paddingHorizontal: 12, paddingVertical: 6,
    borderWidth: 1, borderColor: 'rgba(148,163,184,0.24)',
  },
  qrBtnDisabled: { opacity: 0.35 },
  qrText: { fontSize: 12, color: '#C7D2FE', fontWeight: '700' },

  inputRow: {
    flexDirection: 'row', alignItems: 'flex-end',
    paddingHorizontal: 12, paddingTop: 8, gap: 8,
    backgroundColor: C.bg,
  },
  input: {
    flex: 1, backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 20,
    paddingHorizontal: 16, paddingVertical: 10,
    fontSize: 14, color: C.text, maxHeight: 90,
    borderWidth: 1, borderColor: 'rgba(148,163,184,0.24)',
  },
  sendBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: C.primary,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: C.primary, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4, shadowRadius: 8, elevation: 5,
  },
  sendBtnDisabled: { opacity: 0.4, shadowOpacity: 0 },

  dealBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    margin: 12, padding: 15, borderRadius: 18,
    backgroundColor: C.teal,
  },
  dealBtnPending: { backgroundColor: C.amber },
  dealBtnText: { color: C.white, fontSize: 15, fontWeight: '800' },
  dealConfirmedRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    marginHorizontal: 12, marginBottom: 10,
    backgroundColor: 'rgba(16,185,129,0.1)',
    borderRadius: 14, padding: 10,
    borderWidth: 1, borderColor: 'rgba(16,185,129,0.25)',
  },
  dealConfirmedText: { fontSize: 13, color: C.green, fontWeight: '700' },

  expiredBanner: {
    margin: 12, padding: 14, borderRadius: 16,
    backgroundColor: 'rgba(244,63,94,0.08)',
    borderWidth: 1, borderColor: 'rgba(244,63,94,0.2)',
    alignItems: 'center',
  },
  expiredTitle: { fontSize: 14, fontWeight: '800', color: C.red, marginBottom: 4 },
  expiredSub: { fontSize: 12, color: '#A87070', textAlign: 'center', lineHeight: 18 },
});

const m = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'flex-end', gap: 8 },
  rowMe: { flexDirection: 'row-reverse' },
  systemRow: { alignItems: 'center', marginVertical: 4 },
  systemPill: {
    backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 20,
    paddingHorizontal: 12, paddingVertical: 6, maxWidth: '80%',
  },
  systemText: { fontSize: 11, color: C.textSub, fontWeight: '600', textAlign: 'center' },
  bubble: { maxWidth: '75%', padding: 11, borderRadius: 18 },
  bubbleThem: { backgroundColor: C.surface, borderBottomLeftRadius: 4, borderWidth: 1, borderColor: C.border },
  bubbleMe: { backgroundColor: C.primary, borderBottomRightRadius: 4 },
  senderLabel: { fontSize: 10, fontWeight: '700', color: C.textSub, marginBottom: 3 },
  bubbleText: { fontSize: 14, color: C.text, lineHeight: 20 },
  bubbleTextMe: { color: C.white },
});



