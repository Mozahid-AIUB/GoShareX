
import type { RootNavProp } from '@/navigation/types';
import React, { useState } from 'react';
import {
  View,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
  TouchableOpacity,
  Modal,
  FlatList,
  Pressable,
  Animated,
} from 'react-native';
import { Text } from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import Svg, { Path, Circle } from 'react-native-svg';
import authService from '@/services/firebase/authService';
import { auth } from '@/config/firebase.config';
import { isValidName } from '@/utils/validators';
import { getFCMToken, saveFCMToken } from '@/services/firebase/messaging';

const C = {
  bg: '#F5F3FF',
  surface: '#FFFFFF',
  border: '#E5E0FF',
  borderFocus: '#7C3AED',
  primary: '#7C3AED',
  teal: '#0D9488',
  text: '#1E1040',
  textSub: '#6B7280',
  textMuted: '#A89FC8',
  error: '#DC2626',
  white: '#FFFFFF',
};

const DEPARTMENTS = [
  'CSE - Computer Science & Engineering',
  'BBA - Business Administration',
  'ENG - Engineering',
  'ELL - English Language & Literature',
  'ARD - Architecture & Design',
  'Other',
];

const IconUser = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Circle cx="12" cy="8" r="4" stroke="#6E7E99" strokeWidth="1.8" />
    <Path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);

const IconId = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Rect x="2" y="5" width="20" height="14" rx="3" stroke="#6E7E99" strokeWidth="1.8" />
    <Path d="M8 10h8M8 14h5" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);

const IconDept = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M12 2L2 7v4c0 5 10 10 10 10s10-5 10-10V7l-10-5z" stroke="#6E7E99" strokeWidth="1.8" />
    <Path d="M12 11v5M9 13h6" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);

const IconBack = () => (
  <Svg width={20} height={20} viewBox="0 0 24 24" fill="none">
    <Path d="M19 12H5M5 12L12 19M5 12L12 5" stroke="#A5B4FC" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const Field = ({
  label, value, onChangeText, icon, placeholder, error,
}: {
  label: string; value: string; onChangeText: (t: string) => void;
  icon: React.ReactNode; placeholder?: string; error?: string;
}) => {
  const [focused, setFocused] = useState(false);
  return (
    <View style={f.wrap}>
      <Text style={f.label}>{label}</Text>
      <View style={[f.row, focused && f.rowFocused, !!error && f.rowError]}>
        <View style={f.iconWrap}>{icon}</View>
        <Text
          style={[f.input, !value && f.inputPlaceholder]}
          onPress={() => setFocused(true)}
        >
          {value || placeholder || `Enter ${label.toLowerCase()}`}
        </Text>
      </View>
      {!!error && <Text style={f.errorText}>{error}</Text>}
    </View>
  );
};

const f = StyleSheet.create({
  wrap: { marginBottom: 12 },
  label: { fontSize: 12, fontWeight: '700', color: C.textSub, letterSpacing: 0.5, marginBottom: 6, textTransform: 'uppercase' },
  row: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#F9F7FF', borderRadius: 16,
    borderWidth: 1, borderColor: C.border, height: 52, paddingHorizontal: 14,
  },
  rowFocused: { borderColor: C.borderFocus, backgroundColor: 'rgba(124,58,237,0.05)' },
  rowError: { borderColor: C.error, backgroundColor: '#FEF2F2' },
  iconWrap: { paddingRight: 12 },
  input: { flex: 1, fontSize: 15, color: C.text },
  inputPlaceholder: { color: C.textMuted },
  errorText: { fontSize: 11, color: C.error, marginTop: 4, marginLeft: 4 },
});

const ProfileSetupScreen = () => {
  const navigation = useNavigation<RootNavProp>();
  const [name, setName] = useState('');
  const [department, setDepartment] = useState('');
  const [showDeptModal, setShowDeptModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const btnScale = React.useRef(new Animated.Value(1)).current;

  const onPressIn = () => Animated.spring(btnScale, { toValue: 0.96, useNativeDriver: true, tension: 120 }).start();
  const onPressOut = () => Animated.spring(btnScale, { toValue: 1, useNativeDriver: true, tension: 80 }).start();

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!isValidName(name)) errs.name = 'Please enter your full name';
    if (!department.trim()) errs.department = 'Please select a department';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) return;

    const uid = auth.currentUser?.uid;
    if (!uid) {
      Alert.alert('Error', 'Not logged in');
      return;
    }

    setLoading(true);
    try {
      const deptCode = department.split(' - ')[0];
      await authService.completeProfile(uid, {
        name: name.trim(),
        department: deptCode,
      });

      // Register FCM token
      const fcmToken = await getFCMToken();
      if (fcmToken) {
        await saveFCMToken(uid, fcmToken).catch(e => {
          console.warn('[ProfileSetupScreen] FCM token save failed:', e);
        });
      }

      // AppNavigator will automatically switch to MainApp stack when isAuthenticated becomes true
    } catch (err: any) {
      Alert.alert('Error', err.message ?? 'Failed to save profile');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.root}>
      <View style={styles.radial1} />
      <View style={styles.radial2} />

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>

          {/* Header */}
          <View style={styles.topBar}>
            <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()} activeOpacity={0.7}>
              <IconBack />
              <Text style={styles.backLabel}>Back</Text>
            </TouchableOpacity>
          </View>

          {/* Title */}
          <View style={styles.titleArea}>
            <Text style={styles.title}>Setup your profile</Text>
            <Text style={styles.titleSub}>Complete your information to finish registration</Text>
          </View>

          {/* Form card */}
          <View style={styles.card}>
            <Field
              label="Full Name"
              value={name}
              onChangeText={setName}
              icon={<IconUser />}
              placeholder="e.g. Mozahid Rahman"
              error={errors.name}
            />
            <TouchableOpacity onPress={() => setShowDeptModal(true)} activeOpacity={0.7}>
              <Field
                label="Department"
                value={department}
                onChangeText={() => { }}
                icon={<IconDept />}
                placeholder="Select your department"
                error={errors.department}
              />
            </TouchableOpacity>

            <Animated.View style={{ transform: [{ scale: btnScale }], marginTop: 8 }}>
              <Pressable
                style={[styles.saveBtn, loading && styles.saveBtnDisabled]}
                onPress={handleSave}
                onPressIn={onPressIn}
                onPressOut={onPressOut}
                disabled={loading}
              >
                <Text style={styles.saveBtnText}>
                  {loading ? 'Saving...' : 'Complete Setup'}
                </Text>
              </Pressable>
            </Animated.View>
          </View>

          <Text style={styles.disclaimer}>
            This information helps personalize your GoShareX experience.
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>

      {/* Department Picker Modal */}
      <Modal visible={showDeptModal} transparent animationType="fade">
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setShowDeptModal(false)}
        >
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Select Department</Text>
            <FlatList
              data={DEPARTMENTS}
              keyExtractor={(item) => item}
              scrollEnabled={false}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.deptOption,
                    item === department && styles.deptOptionSelected,
                  ]}
                  onPress={() => {
                    setDepartment(item);
                    setShowDeptModal(false);
                  }}
                >
                  <Text
                    style={[
                      styles.deptOptionText,
                      item === department && styles.deptOptionTextSelected,
                    ]}
                  >
                    {item}
                  </Text>
                </TouchableOpacity>
              )}
            />
          </View>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  radial1: {
    position: 'absolute', top: -60, right: -50,
    width: 240, height: 240, borderRadius: 120,
    backgroundColor: 'rgba(124,58,237,0.10)',
  },
  radial2: {
    position: 'absolute', bottom: -50, left: -40,
    width: 200, height: 200, borderRadius: 100,
    backgroundColor: 'rgba(13,148,136,0.07)',
  },
  scroll: { flexGrow: 1, padding: 24, paddingBottom: 40 },
  topBar: { marginBottom: 28 },
  backBtn: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  backLabel: { fontSize: 13, fontWeight: '600', color: '#A5B4FC' },
  titleArea: { marginBottom: 24 },
  title: { fontSize: 26, fontWeight: '900', color: C.text, letterSpacing: -0.6 },
  titleSub: { fontSize: 13, color: C.textSub, marginTop: 4 },
  card: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1, borderColor: '#EDE9FE',
    borderRadius: 28, padding: 22, marginBottom: 20,
    shadowColor: '#7C3AED', shadowOpacity: 0.07, shadowRadius: 16,
    shadowOffset: { width: 0, height: 4 }, elevation: 3,
  },
  saveBtn: {
    height: 54, borderRadius: 18,
    backgroundColor: C.primary,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: C.primary, shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.45, shadowRadius: 16, elevation: 8,
  },
  saveBtnDisabled: { opacity: 0.6 },
  saveBtnText: { fontSize: 16, fontWeight: '800', color: C.white, letterSpacing: -0.2 },
  disclaimer: { fontSize: 11, color: C.textMuted, textAlign: 'center', lineHeight: 17, paddingHorizontal: 8 },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 28,
    padding: 20,
    width: '85%',
    borderWidth: 1,
    borderColor: '#EDE9FE',
    maxHeight: '60%',
    shadowColor: '#7C3AED', shadowOpacity: 0.10, shadowRadius: 20,
    shadowOffset: { width: 0, height: 6 }, elevation: 8,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: C.text,
    marginBottom: 16,
  },
  deptOption: {
    paddingVertical: 13,
    paddingHorizontal: 14,
    borderRadius: 12,
    marginBottom: 8,
    backgroundColor: '#F9F7FF',
    borderWidth: 1,
    borderColor: '#E5E0FF',
  },
  deptOptionSelected: {
    backgroundColor: 'rgba(124,58,237,0.08)',
    borderColor: C.primary,
  },
  deptOptionText: {
    fontSize: 14,
    color: C.textSub,
    fontWeight: '600',
  },
  deptOptionTextSelected: {
    color: C.primary,
    fontWeight: '700',
  },
});

export default ProfileSetupScreen;
