import React, { useRef, useState } from 'react';
import {
  Animated,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
  Alert,
} from 'react-native';
import { Text } from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import Svg, { Circle, Defs, LinearGradient, Path, Stop, Rect } from 'react-native-svg';

import { RootNavProp } from '@/navigation/types';
import authService from '@/services/firebase/authService';
import { useAuthStore } from '@/store';
import { getFCMToken, saveFCMToken } from '@/services/firebase/messaging';
import { checkSuspension } from '@/services/firebase/badgeService';

// ─── Design tokens ────────────────────────────────────────────────────────────
const C = {
  bg: '#F5F3FF',
  surface: '#FFFFFF',
  border: '#E5E0FF',
  borderFocus: '#7C3AED',
  primary: '#7C3AED',
  teal: '#0D9488',
  text: '#1E1040',
  textSub: '#6B7280',
  textMuted: '#A89FC8',
  error: '#DC2626',
  white: '#FFFFFF',
};

// ─── SVG Icons ────────────────────────────────────────────────────────────────
const LogoMark = ({ size = 48 }: { size?: number }) => (
  <Svg width={size} height={size} viewBox="0 0 48 48" fill="none">
    <Defs>
      <LinearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
        <Stop offset="0" stopColor="#6366F1" />
        <Stop offset="1" stopColor="#14B8A6" />
      </LinearGradient>
    </Defs>
    <Rect width="48" height="48" rx="16" fill="url(#lg)" />
    {/* Two cars sharing road */}
    <Rect x="6" y="22" width="16" height="10" rx="3" fill="rgba(255,255,255,0.9)" />
    <Path d="M9 22 Q10 17 14 16 H18 Q22 17 22 22 Z" fill="rgba(255,255,255,0.7)" />
    <Circle cx="10" cy="32" r="2.5" fill="#4F46E5" />
    <Circle cx="19" cy="32" r="2.5" fill="#4F46E5" />
    <Rect x="26" y="22" width="16" height="10" rx="3" fill="rgba(255,255,255,0.9)" />
    <Path d="M29 22 Q30 17 34 16 H38 Q42 17 42 22 Z" fill="rgba(255,255,255,0.7)" />
    <Circle cx="30" cy="32" r="2.5" fill="#0F766E" />
    <Circle cx="39" cy="32" r="2.5" fill="#0F766E" />
    <Rect x="6" y="33" width="36" height="4" rx="2" fill="rgba(255,255,255,0.15)" />
    <Rect x="20" y="35" width="8" height="1.5" rx="0.75" fill="rgba(255,255,255,0.4)" />
  </Svg>
);

const IconEmail = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    <Path d="M22 6l-10 7L2 6" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const IconLock = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Rect x="3" y="11" width="18" height="11" rx="2" stroke="#6E7E99" strokeWidth="1.8" />
    <Path d="M7 11V7a5 5 0 0110 0v4" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);

const IconEye = ({ off }: { off?: boolean }) => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    {off ? (
      <>
        <Path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
        <Path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
        <Path d="M1 1l22 22" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
      </>
    ) : (
      <>
        <Path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="#6E7E99" strokeWidth="1.8" />
        <Circle cx="12" cy="12" r="3" stroke="#6E7E99" strokeWidth="1.8" />
      </>
    )}
  </Svg>
);

const IconArrow = () => (
  <Svg width={20} height={20} viewBox="0 0 24 24" fill="none">
    <Path d="M5 12h14M12 5l7 7-7 7" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

// ─── Field component ──────────────────────────────────────────────────────────
const Field = ({
  label, value, onChangeText, icon, secure, onToggleSecure,
  keyboardType, autoCapitalize, error,
}: {
  label: string; value: string; onChangeText: (t: string) => void;
  icon: React.ReactNode; secure?: boolean; onToggleSecure?: () => void;
  keyboardType?: any; autoCapitalize?: any; error?: string;
}) => {
  const [focused, setFocused] = useState(false);
  return (
    <View style={f.wrap}>
      <Text style={f.label}>{label}</Text>
      <View style={[f.row, focused && f.rowFocused, !!error && f.rowError]}>
        <View style={f.iconWrap}>{icon}</View>
        <TextInput
          style={f.input}
          value={value}
          onChangeText={onChangeText}
          placeholder={`Enter ${label.toLowerCase()}`}
          placeholderTextColor={C.textMuted}
          secureTextEntry={secure}
          keyboardType={keyboardType ?? 'default'}
          autoCapitalize={autoCapitalize ?? 'none'}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
        />
        {onToggleSecure && (
          <TouchableOpacity style={f.eyeBtn} onPress={onToggleSecure} activeOpacity={0.7}>
            <IconEye off={secure} />
          </TouchableOpacity>
        )}
      </View>
      {!!error && <Text style={f.errorText}>{error}</Text>}
    </View>
  );
};

const f = StyleSheet.create({
  wrap: { marginBottom: 14 },
  label: { fontSize: 12, fontWeight: '700', color: C.textSub, letterSpacing: 0.5, marginBottom: 6, textTransform: 'uppercase' },
  row: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#F9F7FF', borderRadius: 16,
    borderWidth: 1, borderColor: C.border, height: 52,
  },
  rowFocused: { borderColor: C.borderFocus, backgroundColor: 'rgba(124,58,237,0.05)' },
  rowError: { borderColor: C.error, backgroundColor: '#FEF2F2' },
  iconWrap: { paddingHorizontal: 14 },
  input: { flex: 1, fontSize: 15, color: C.text, paddingRight: 12 },
  eyeBtn: { paddingHorizontal: 14, height: '100%', alignItems: 'center', justifyContent: 'center' },
  errorText: { fontSize: 11, color: C.error, marginTop: 4, marginLeft: 4 },
});

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function LoginScreen() {
  const navigation = useNavigation<RootNavProp>();
  const { setUser } = useAuthStore();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [emailError, setEmailError] = useState('');
  const btnScale = useRef(new Animated.Value(1)).current;

  const onPressIn = () => Animated.spring(btnScale, { toValue: 0.96, useNativeDriver: true, tension: 120 }).start();
  const onPressOut = () => Animated.spring(btnScale, { toValue: 1, useNativeDriver: true, tension: 80 }).start();

  const handleLogin = async () => {
    setEmailError('');
    if (!email.trim() || !password) {
      Alert.alert('Missing fields', 'Please enter your email and password.');
      return;
    }
    if (!isValidEmail(email.trim().toLowerCase())) {
      setEmailError('Please enter a valid email address');
      return;
    }
    setLoading(true);
    try {
      const user = await authService.login({ email: email.trim().toLowerCase(), password });

      // authService already signs out suspended users and throws {code:'USER_SUSPENDED'}
      // but as a second safety net, check via badgeService (covers fallback user path)
      const suspensionStatus = await checkSuspension(user.uid);
      if (suspensionStatus.suspended) {
        const suspendedUntil = user.suspendedUntil ?? (Date.now() + 24 * 3600000);
        const remainingMs = suspendedUntil - Date.now();
        navigation.replace('Suspension', {
          suspendedUntil,
          remainingHours: Math.max(1, Math.ceil(remainingMs / 3600000)),
          reason: suspensionStatus.reason ?? 'Too many ride cancellations.',
        });
        return;
      }

      setUser(user);
      // AppNavigator will automatically switch to MainApp stack when isAuthenticated becomes true
    } catch (error: any) {
      // authService throws plain object {code:'USER_SUSPENDED', suspendedUntil} for suspended users
      if (error?.code === 'USER_SUSPENDED') {
        const suspendedUntil: number = error.suspendedUntil ?? (Date.now() + 24 * 3600000);
        const remainingMs = suspendedUntil - Date.now();
        navigation.replace('Suspension', {
          suspendedUntil,
          remainingHours: Math.max(1, Math.ceil(remainingMs / 3600000)),
          reason: 'Your account has been suspended due to repeated ride cancellations.',
        });
        return;
      }
      Alert.alert('Login failed', error?.message ?? 'Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

return (
  <SafeAreaView style={s.root}>
    {/* Background radials */}
    <View style={s.radial1} />
    <View style={s.radial2} />

    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>

        {/* Logo */}
        <View style={s.logoArea}>
          <LogoMark size={64} />
          <View style={s.logoTextWrap}>
            <Text style={s.logoName}>Go<Text style={s.logoAccent}>Share</Text>X</Text>
            <Text style={s.logoSub}>Smart Ride Sharing</Text>
          </View>
        </View>

        {/* Card */}
        <View style={s.card}>
          <Text style={s.cardTitle}>Welcome back</Text>
          <Text style={s.cardSub}>Sign in to continue</Text>

          <Field
            label="Email"
            value={email}
            onChangeText={setEmail}
            icon={<IconEmail />}
            keyboardType="email-address"
            error={emailError}
          />
          <Field
            label="Password"
            value={password}
            onChangeText={setPassword}
            icon={<IconLock />}
            secure={!showPassword}
            onToggleSecure={() => setShowPassword(v => !v)}
          />

          <Animated.View style={{ transform: [{ scale: btnScale }] }}>
            <Pressable
              style={[s.loginBtn, loading && s.loginBtnDisabled]}
              onPress={handleLogin}
              onPressIn={onPressIn}
              onPressOut={onPressOut}
              disabled={loading}
            >
              {loading ? (
                <Text style={s.loginBtnText}>Signing in...</Text>
              ) : (
                <>
                  <Text style={s.loginBtnText}>Sign In</Text>
                  <IconArrow />
                </>
              )}
            </Pressable>
          </Animated.View>

          <TouchableOpacity
            style={s.registerLink}
            onPress={() => navigation.navigate('Auth', { screen: 'Register' })}
            disabled={loading}
            activeOpacity={0.7}
          >
            <Text style={s.registerLinkText}>
              Don&apos;t have an account? <Text style={s.registerLinkAccent}>Create one</Text>
            </Text>
          </TouchableOpacity>
        </View>

        {/* Disclaimer */}
        <Text style={s.disclaimer}>
          By signing in you agree to GoShareX&apos;s Terms of Service and Privacy Policy.{'\n'}
          GoShareX is not liable for any financial loss or disputes between riders.
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  </SafeAreaView>
);
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  radial1: {
    position: 'absolute', top: -60, right: -50,
    width: 260, height: 260, borderRadius: 130,
    backgroundColor: 'rgba(124,58,237,0.10)',
  },
  radial2: {
    position: 'absolute', bottom: -50, left: -40,
    width: 220, height: 220, borderRadius: 110,
    backgroundColor: 'rgba(13,148,136,0.07)',
  },
  scroll: { flexGrow: 1, padding: 24, justifyContent: 'center' },
  logoArea: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 32, alignSelf: 'center' },
  logoTextWrap: { gap: 2 },
  logoName: { fontSize: 28, fontWeight: '900', color: C.white, letterSpacing: -0.8 },
  logoAccent: { color: C.primary },
  logoSub: { fontSize: 12, color: C.textSub, fontWeight: '500' },
  card: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1, borderColor: '#EDE9FE',
    shadowColor: '#7C3AED', shadowOpacity: 0.07, shadowRadius: 16,
    shadowOffset: { width: 0, height: 4 }, elevation: 3,
    borderRadius: 28, padding: 24, marginBottom: 20,
  },
  cardTitle: { fontSize: 22, fontWeight: '800', color: C.text, marginBottom: 4, letterSpacing: -0.4 },
  cardSub: { fontSize: 13, color: C.textSub, marginBottom: 24 },
  loginBtn: {
    height: 54, borderRadius: 18,
    backgroundColor: C.primary,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    marginTop: 4,
    shadowColor: C.primary, shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.45, shadowRadius: 16, elevation: 8,
  },
  loginBtnDisabled: { opacity: 0.6 },
  loginBtnText: { fontSize: 16, fontWeight: '800', color: C.white, letterSpacing: -0.2 },
  registerLink: { alignItems: 'center', marginTop: 18 },
  registerLinkText: { fontSize: 13, color: C.textSub },
  registerLinkAccent: { color: C.primary, fontWeight: '700' },
  disclaimer: { fontSize: 11, color: C.textMuted, textAlign: 'center', lineHeight: 17, paddingHorizontal: 8 },
});
