import React, { useEffect, useRef } from 'react';
import {
  Animated,
  Easing,
  StyleSheet,
  View,
} from 'react-native';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import Svg, {
  Circle,
  Defs,
  Ellipse,
  G,
  LinearGradient,
  Path,
  Rect,
  Stop,
} from 'react-native-svg';

import { auth } from '@/config/firebase.config';
import { useAuthStore } from '@/store';
import authService from '@/services/firebase/authService';
import { checkSuspension } from '@/services/firebase/badgeService';

// ─── Premium Ride Share SVG Icon ─────────────────────────────────────────────
const RideShareIcon = ({ size = 100 }: { size?: number }) => (
  <Svg width={size} height={size} viewBox="0 0 120 120" fill="none">
    <Defs>
      <LinearGradient id="iconBg" x1="0" y1="0" x2="1" y2="1">
        <Stop offset="0" stopColor="#6366F1" />
        <Stop offset="1" stopColor="#14B8A6" />
      </LinearGradient>
      <LinearGradient id="road" x1="0" y1="0" x2="0" y2="1">
        <Stop offset="0" stopColor="#1E2A50" />
        <Stop offset="1" stopColor="#0A0F1E" />
      </LinearGradient>
      <LinearGradient id="car1" x1="0" y1="0" x2="1" y2="1">
        <Stop offset="0" stopColor="#818CF8" />
        <Stop offset="1" stopColor="#6366F1" />
      </LinearGradient>
      <LinearGradient id="car2" x1="0" y1="0" x2="1" y2="1">
        <Stop offset="0" stopColor="#2DD4BF" />
        <Stop offset="1" stopColor="#14B8A6" />
      </LinearGradient>
      <LinearGradient id="glow" x1="0.5" y1="0" x2="0.5" y2="1">
        <Stop offset="0" stopColor="#6366F1" stopOpacity="0.3" />
        <Stop offset="1" stopColor="#6366F1" stopOpacity="0" />
      </LinearGradient>
    </Defs>

    {/* Outer ring */}
    <Circle cx="60" cy="60" r="58" fill="rgba(99,102,241,0.08)" />
    <Circle cx="60" cy="60" r="55" stroke="url(#iconBg)" strokeWidth="1.5" fill="none" opacity="0.4" />

    {/* Background glow */}
    <Ellipse cx="60" cy="75" rx="45" ry="18" fill="url(#glow)" />

    {/* Road */}
    <Rect x="10" y="72" width="100" height="18" rx="9" fill="url(#road)" />
    {/* Road dashes */}
    <Rect x="30" y="79" width="14" height="3" rx="1.5" fill="rgba(255,255,255,0.2)" />
    <Rect x="53" y="79" width="14" height="3" rx="1.5" fill="rgba(255,255,255,0.2)" />
    <Rect x="76" y="79" width="14" height="3" rx="1.5" fill="rgba(255,255,255,0.2)" />

    {/* Car 1 (left — indigo) */}
    <G>
      {/* Body */}
      <Rect x="12" y="54" width="40" height="20" rx="6" fill="url(#car1)" />
      {/* Roof */}
      <Path d="M20 54 Q22 44 30 43 H42 Q50 44 50 54 Z" fill="#A5B4FC" opacity="0.9" />
      {/* Windows */}
      <Rect x="23" y="45" width="10" height="9" rx="2" fill="#C7D2FE" opacity="0.6" />
      <Rect x="36" y="45" width="10" height="9" rx="2" fill="#C7D2FE" opacity="0.6" />
      {/* Wheels */}
      <Circle cx="22" cy="74" r="5" fill="#1E2A50" />
      <Circle cx="22" cy="74" r="2.5" fill="#6366F1" />
      <Circle cx="42" cy="74" r="5" fill="#1E2A50" />
      <Circle cx="42" cy="74" r="2.5" fill="#6366F1" />
      {/* Headlight */}
      <Ellipse cx="52" cy="61" rx="2" ry="3" fill="#FEF08A" opacity="0.9" />
    </G>

    {/* Car 2 (right — teal) */}
    <G>
      {/* Body */}
      <Rect x="68" y="54" width="40" height="20" rx="6" fill="url(#car2)" />
      {/* Roof */}
      <Path d="M76 54 Q78 44 86 43 H98 Q106 44 106 54 Z" fill="#5EEAD4" opacity="0.9" />
      {/* Windows */}
      <Rect x="79" y="45" width="10" height="9" rx="2" fill="#CCFBF1" opacity="0.6" />
      <Rect x="92" y="45" width="10" height="9" rx="2" fill="#CCFBF1" opacity="0.6" />
      {/* Wheels */}
      <Circle cx="78" cy="74" r="5" fill="#1E2A50" />
      <Circle cx="78" cy="74" r="2.5" fill="#14B8A6" />
      <Circle cx="98" cy="74" r="5" fill="#1E2A50" />
      <Circle cx="98" cy="74" r="2.5" fill="#14B8A6" />
      {/* Tail light */}
      <Rect x="68" y="59" width="2" height="6" rx="1" fill="#FCA5A5" opacity="0.9" />
    </G>

    {/* Share / connection arc between cars */}
    <Path
      d="M52 58 Q60 48 68 58"
      stroke="url(#iconBg)"
      strokeWidth="2"
      fill="none"
      strokeDasharray="3 2"
      strokeLinecap="round"
    />
    {/* Center dot */}
    <Circle cx="60" cy="50" r="4" fill="url(#iconBg)" />
    <Circle cx="60" cy="50" r="2" fill="#fff" opacity="0.9" />

    {/* Speed lines left */}
    <Path d="M8 62 L14 62" stroke="#818CF8" strokeWidth="1.5" strokeLinecap="round" opacity="0.5" />
    <Path d="M6 67 L10 67" stroke="#818CF8" strokeWidth="1.5" strokeLinecap="round" opacity="0.3" />
    {/* Speed lines right */}
    <Path d="M110 62 L116 62" stroke="#2DD4BF" strokeWidth="1.5" strokeLinecap="round" opacity="0.5" />
    <Path d="M112 67 L116 67" stroke="#2DD4BF" strokeWidth="1.5" strokeLinecap="round" opacity="0.3" />
  </Svg>
);

// ─── Animated Letter for logo ─────────────────────────────────────────────────
// ─── Main Splash ──────────────────────────────────────────────────────────────
const SplashScreen = () => {
  const { setUser, setLoading } = useAuthStore();
  const resolved = useRef(false);

  // Animations
  const iconScale = useRef(new Animated.Value(0.4)).current;
  const iconOpacity = useRef(new Animated.Value(0)).current;
  const titleOpacity = useRef(new Animated.Value(0)).current;
  const titleY = useRef(new Animated.Value(20)).current;
  const subtitleOpacity = useRef(new Animated.Value(0)).current;
  const dotOpacity1 = useRef(new Animated.Value(0.2)).current;
  const dotOpacity2 = useRef(new Animated.Value(0.2)).current;
  const dotOpacity3 = useRef(new Animated.Value(0.2)).current;
  const ringScale = useRef(new Animated.Value(0.8)).current;
  const ringOpacity = useRef(new Animated.Value(0.6)).current;

  const buildFallbackUser = (firebaseUser: FirebaseUser) => {
    const email = (firebaseUser.email ?? '').trim().toLowerCase();
    const name = email.split('@')[0] || firebaseUser.displayName || 'AIUB Student';
    return {
      uid: firebaseUser.uid, email, name,
      studentId: '', department: '', phoneNumber: '',
      rating: 5, totalRides: 0, totalSaved: 0,
      completionRate: 100, badge: 'New Rider' as const,
      strikes: 0, isSuspended: false,
      createdAt: new Date().toISOString(),
    };
  };

  useEffect(() => {
    // ── Entrance animations
    Animated.sequence([
      Animated.parallel([
        Animated.spring(iconScale, { toValue: 1, tension: 60, friction: 7, useNativeDriver: true }),
        Animated.timing(iconOpacity, { toValue: 1, duration: 500, easing: Easing.out(Easing.quad), useNativeDriver: true }),
        Animated.timing(ringScale, { toValue: 1.15, duration: 800, easing: Easing.out(Easing.quad), useNativeDriver: true }),
        Animated.timing(ringOpacity, { toValue: 0, duration: 800, useNativeDriver: true }),
      ]),
      Animated.parallel([
        Animated.timing(titleOpacity, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.spring(titleY, { toValue: 0, tension: 80, friction: 8, useNativeDriver: true }),
      ]),
      Animated.timing(subtitleOpacity, { toValue: 1, duration: 350, useNativeDriver: true }),
    ]).start();

    // Loading dots loop
    const dotLoop = () => {
      Animated.sequence([
        Animated.timing(dotOpacity1, { toValue: 1, duration: 300, useNativeDriver: true }),
        Animated.timing(dotOpacity2, { toValue: 1, duration: 300, useNativeDriver: true }),
        Animated.timing(dotOpacity3, { toValue: 1, duration: 300, useNativeDriver: true }),
        Animated.parallel([
          Animated.timing(dotOpacity1, { toValue: 0.2, duration: 200, useNativeDriver: true }),
          Animated.timing(dotOpacity2, { toValue: 0.2, duration: 200, useNativeDriver: true }),
          Animated.timing(dotOpacity3, { toValue: 0.2, duration: 200, useNativeDriver: true }),
        ]),
      ]).start(() => dotLoop());
    };
    dotLoop();

    // ── Auth listener — only update the store; AppNavigator reacts to state changes
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (resolved.current) return;
      resolved.current = true;

      if (firebaseUser) {
        // Set a fallback immediately so MainApp renders while we fetch the full profile
        setUser(buildFallbackUser(firebaseUser));

        try {
          const userData = await authService.getCurrentUser();
          if (userData) {
            // Check suspension before granting access
            const suspension = await checkSuspension(userData.uid);
            if (suspension.suspended) {
              // Sign out and let AppNavigator show Auth; LoginScreen will route to Suspension
              const { signOut } = await import('firebase/auth');
              await signOut(auth);
              setUser(null);
              setLoading(false);
              return;
            }
            setUser(userData);
          }
        } catch {
          // fallback user already in store — proceed
        }
      } else {
        // Not logged in — clear user so AppNavigator shows Auth screens
        setUser(null);
      }

      setLoading(false);
    });

    return unsubscribe;
  }, []);

  return (
    <View style={s.root}>
      {/* Mesh background radials */}
      <View style={s.radial1} />
      <View style={s.radial2} />

      {/* Expanding ring pulse */}
      <Animated.View style={[s.ring, { transform: [{ scale: ringScale }], opacity: ringOpacity }]} />

      {/* Icon */}
      <Animated.View style={{ transform: [{ scale: iconScale }], opacity: iconOpacity }}>
        <RideShareIcon size={120} />
      </Animated.View>

      {/* Logo name */}
      <Animated.Text style={[s.logoName, { opacity: titleOpacity, transform: [{ translateY: titleY }] }]}>
        Go<Animated.Text style={s.logoAccent}>Share</Animated.Text>X
      </Animated.Text>

      {/* Tagline */}
      <Animated.Text style={[s.tagline, { opacity: subtitleOpacity }]}>
        Share rides · Save money · AIUB
      </Animated.Text>

      {/* Loading dots */}
      <View style={s.dotsRow}>
        <Animated.View style={[s.dot, { opacity: dotOpacity1 }]} />
        <Animated.View style={[s.dot, s.dotMid, { opacity: dotOpacity2 }]} />
        <Animated.View style={[s.dot, { opacity: dotOpacity3 }]} />
      </View>
    </View>
  );
};

const s = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#080C14',
    alignItems: 'center',
    justifyContent: 'center',
  },
  radial1: {
    position: 'absolute', top: -80, right: -60,
    width: 320, height: 320, borderRadius: 160,
    backgroundColor: 'rgba(99,102,241,0.18)',
  },
  radial2: {
    position: 'absolute', bottom: -100, left: -80,
    width: 280, height: 280, borderRadius: 140,
    backgroundColor: 'rgba(20,184,166,0.12)',
  },
  ring: {
    position: 'absolute',
    width: 200, height: 200, borderRadius: 100,
    borderWidth: 1.5,
    borderColor: 'rgba(99,102,241,0.5)',
  },
  logoName: {
    marginTop: 28,
    fontSize: 36,
    fontWeight: '900',
    color: '#FFFFFF',
    letterSpacing: -1,
  },
  logoAccent: {
    color: '#6366F1',
  },
  tagline: {
    marginTop: 8,
    fontSize: 13,
    fontWeight: '500',
    color: '#6E7E99',
    letterSpacing: 0.3,
  },
  dotsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 52,
    gap: 8,
  },
  dot: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
    backgroundColor: '#6366F1',
  },
  dotMid: {
    backgroundColor: '#14B8A6',
  },
});

export default SplashScreen;
