import { RootNavProp } from '@/navigation/types';
import React, { useRef, useState } from 'react';
import {
  Animated,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
  Alert,
} from 'react-native';
import { Text } from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import Svg, { Circle, Defs, LinearGradient, Path, Rect, Stop } from 'react-native-svg';

import authService from '@/services/firebase/authService';
import { isValidEmail, isValidName } from '@/utils/validators';
import { useAuthStore } from '@/store';

const C = {
  bg: '#F5F3FF',
  surface: '#FFFFFF',
  border: '#E5E0FF',
  borderFocus: '#7C3AED',
  primary: '#7C3AED',
  teal: '#0D9488',
  text: '#1E1040',
  textSub: '#6B7280',
  textMuted: '#A89FC8',
  error: '#DC2626',
  white: '#FFFFFF',
};

// ─── SVG Icons ────────────────────────────────────────────────────────────────
const LogoMark = ({ size = 40 }: { size?: number }) => (
  <Svg width={size} height={size} viewBox="0 0 48 48" fill="none">
    <Defs>
      <LinearGradient id="lg2" x1="0" y1="0" x2="1" y2="1">
        <Stop offset="0" stopColor="#6366F1" />
        <Stop offset="1" stopColor="#14B8A6" />
      </LinearGradient>
    </Defs>
    <Rect width="48" height="48" rx="16" fill="url(#lg2)" />
    <Rect x="6" y="22" width="16" height="10" rx="3" fill="rgba(255,255,255,0.9)" />
    <Path d="M9 22 Q10 17 14 16 H18 Q22 17 22 22 Z" fill="rgba(255,255,255,0.7)" />
    <Circle cx="10" cy="32" r="2.5" fill="#4F46E5" />
    <Circle cx="19" cy="32" r="2.5" fill="#4F46E5" />
    <Rect x="26" y="22" width="16" height="10" rx="3" fill="rgba(255,255,255,0.9)" />
    <Path d="M29 22 Q30 17 34 16 H38 Q42 17 42 22 Z" fill="rgba(255,255,255,0.7)" />
    <Circle cx="30" cy="32" r="2.5" fill="#0F766E" />
    <Circle cx="39" cy="32" r="2.5" fill="#0F766E" />
    <Rect x="6" y="33" width="36" height="4" rx="2" fill="rgba(255,255,255,0.15)" />
  </Svg>
);

const IconUser = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Circle cx="12" cy="8" r="4" stroke="#6E7E99" strokeWidth="1.8" />
    <Path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);

const IconEmail = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" stroke="#6E7E99" strokeWidth="1.8" />
    <Path d="M22 6l-10 7L2 6" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);


const IconLock = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Rect x="3" y="11" width="18" height="11" rx="2" stroke="#6E7E99" strokeWidth="1.8" />
    <Path d="M7 11V7a5 5 0 0110 0v4" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);

const IconEye = ({ off }: { off?: boolean }) => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    {off ? (
      <>
        <Path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
        <Path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
        <Path d="M1 1l22 22" stroke="#6E7E99" strokeWidth="1.8" strokeLinecap="round" />
      </>
    ) : (
      <>
        <Path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="#6E7E99" strokeWidth="1.8" />
        <Circle cx="12" cy="12" r="3" stroke="#6E7E99" strokeWidth="1.8" />
      </>
    )}
  </Svg>
);

const IconArrow = () => (
  <Svg width={20} height={20} viewBox="0 0 24 24" fill="none">
    <Path d="M5 12h14M12 5l7 7-7 7" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const IconBack = () => (
  <Svg width={20} height={20} viewBox="0 0 24 24" fill="none">
    <Path d="M19 12H5M5 12L12 19M5 12L12 5" stroke="#A5B4FC" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

// ─── Field ────────────────────────────────────────────────────────────────────
const Field = ({
  label, value, onChangeText, icon, secure, onToggleSecure,
  keyboardType, autoCapitalize, placeholder, error,
}: {
  label: string; value: string; onChangeText: (t: string) => void;
  icon: React.ReactNode; secure?: boolean; onToggleSecure?: () => void;
  keyboardType?: any; autoCapitalize?: any; placeholder?: string; error?: string;
}) => {
  const [focused, setFocused] = useState(false);
  return (
    <View style={f.wrap}>
      <Text style={f.label}>{label}</Text>
      <View style={[f.row, focused && f.rowFocused, !!error && f.rowError]}>
        <View style={f.iconWrap}>{icon}</View>
        <TextInput
          style={f.input}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder ?? `Enter ${label.toLowerCase()}`}
          placeholderTextColor={C.textMuted}
          secureTextEntry={secure}
          keyboardType={keyboardType ?? 'default'}
          autoCapitalize={autoCapitalize ?? 'none'}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
        />
        {onToggleSecure && (
          <TouchableOpacity style={f.eyeBtn} onPress={onToggleSecure} activeOpacity={0.7}>
            <IconEye off={secure} />
          </TouchableOpacity>
        )}
      </View>
      {!!error && <Text style={f.errorText}>{error}</Text>}
    </View>
  );
};

const f = StyleSheet.create({
  wrap: { marginBottom: 12 },
  label: { fontSize: 12, fontWeight: '700', color: C.textSub, letterSpacing: 0.5, marginBottom: 6, textTransform: 'uppercase' },
  row: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#F9F7FF', borderRadius: 16,
    borderWidth: 1, borderColor: C.border, height: 52,
  },
  rowFocused: { borderColor: C.borderFocus, backgroundColor: 'rgba(124,58,237,0.05)' },
  rowError: { borderColor: C.error, backgroundColor: '#FEF2F2' },
  iconWrap: { paddingHorizontal: 14 },
  input: { flex: 1, fontSize: 15, color: C.text, paddingRight: 12 },
  eyeBtn: { paddingHorizontal: 14, height: '100%', alignItems: 'center', justifyContent: 'center' },
  errorText: { fontSize: 11, color: C.error, marginTop: 4, marginLeft: 4 },
});

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function RegisterScreen() {
  const navigation = useNavigation<RootNavProp>();
  const { setUser } = useAuthStore();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const btnScale = useRef(new Animated.Value(1)).current;
  const onPressIn = () => Animated.spring(btnScale, { toValue: 0.96, useNativeDriver: true, tension: 120 }).start();
  const onPressOut = () => Animated.spring(btnScale, { toValue: 1, useNativeDriver: true, tension: 80 }).start();

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    const normEmail = email.trim().toLowerCase();
    if (!isValidName(name.trim())) errs.name = 'Please enter your full name';
    if (!isValidEmail(normEmail)) errs.email = 'Please enter a valid email address';
    if (password.length < 6) errs.password = 'At least 6 characters';
    if (password !== confirmPassword) errs.confirmPassword = 'Passwords do not match';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleRegister = async () => {
    if (!validate()) return;
    const normEmail = email.trim().toLowerCase();
    setLoading(true);
    try {
      const newUser = await authService.register({
        name: name.trim(),
        email: normEmail,
        password,
      });
      setUser(newUser);
      navigation.navigate('Auth', {
        screen: 'ProfileSetup',
        params: { uid: newUser.uid, email: newUser.email },
      });
    } catch (err: any) {
      Alert.alert('Registration failed', err.message ?? 'Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={s.root}>
      <View style={s.radial1} />
      <View style={s.radial2} />

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>

          {/* Header */}
          <View style={s.topBar}>
            <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()} activeOpacity={0.7}>
              <IconBack />
              <Text style={s.backLabel}>Back</Text>
            </TouchableOpacity>
            <LogoMark size={40} />
          </View>

          {/* Title */}
          <View style={s.titleArea}>
            <Text style={s.title}>Create account</Text>
            <Text style={s.titleSub}>Create your GoShareX account</Text>
          </View>

          {/* Form card */}
          <View style={s.card}>
            <Field label="Full Name" value={name} onChangeText={setName}
              icon={<IconUser />} autoCapitalize="words" error={errors.name}
              placeholder="e.g. Mozahid Rahman" />
            <Field label="Email" value={email} onChangeText={setEmail}
              icon={<IconEmail />} keyboardType="email-address" error={errors.email}
              placeholder="your@email.com" />
            <Field label="Password" value={password} onChangeText={setPassword}
              icon={<IconLock />} secure={!showPassword}
              onToggleSecure={() => setShowPassword(v => !v)} error={errors.password} />
            <Field label="Confirm Password" value={confirmPassword} onChangeText={setConfirmPassword}
              icon={<IconLock />} secure={!showPassword} error={errors.confirmPassword} />

            <Animated.View style={{ transform: [{ scale: btnScale }] }}>
              <Pressable
                style={[s.registerBtn, loading && s.registerBtnDisabled]}
                onPress={handleRegister}
                onPressIn={onPressIn}
                onPressOut={onPressOut}
                disabled={loading}
              >
                {loading ? (
                  <Text style={s.registerBtnText}>Creating account...</Text>
                ) : (
                  <>
                    <Text style={s.registerBtnText}>Create Account</Text>
                    <IconArrow />
                  </>
                )}
              </Pressable>
            </Animated.View>

            <TouchableOpacity style={s.loginLink} onPress={() => navigation.goBack()} disabled={loading} activeOpacity={0.7}>
              <Text style={s.loginLinkText}>
                Already have an account? <Text style={s.loginLinkAccent}>Sign in</Text>
              </Text>
            </TouchableOpacity>
          </View>

          <Text style={s.disclaimer}>
            By creating an account you agree to GoShareX Terms & Privacy Policy.{'\n'}
            GoShareX is not responsible for any financial loss or disputes.
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  radial1: {
    position: 'absolute', top: -60, right: -50,
    width: 240, height: 240, borderRadius: 120,
    backgroundColor: 'rgba(124,58,237,0.10)',
  },
  radial2: {
    position: 'absolute', bottom: -50, left: -40,
    width: 200, height: 200, borderRadius: 100,
    backgroundColor: 'rgba(13,148,136,0.07)',
  },
  scroll: { flexGrow: 1, padding: 24, paddingBottom: 40 },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28 },
  backBtn: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  backLabel: { fontSize: 13, fontWeight: '600', color: '#A5B4FC' },
  titleArea: { marginBottom: 24 },
  title: { fontSize: 26, fontWeight: '900', color: C.text, letterSpacing: -0.6 },
  titleSub: { fontSize: 13, color: C.textSub, marginTop: 4 },
  card: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1, borderColor: '#EDE9FE',
    borderRadius: 28, padding: 22, marginBottom: 20,
    shadowColor: '#7C3AED', shadowOpacity: 0.07, shadowRadius: 16,
    shadowOffset: { width: 0, height: 4 }, elevation: 3,
  },
  registerBtn: {
    height: 54, borderRadius: 18,
    backgroundColor: C.primary,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    marginTop: 8,
    shadowColor: C.primary, shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35, shadowRadius: 12, elevation: 6,
  },
  registerBtnDisabled: { opacity: 0.6 },
  registerBtnText: { fontSize: 16, fontWeight: '800', color: C.white, letterSpacing: -0.2 },
  loginLink: { alignItems: 'center', marginTop: 18 },
  loginLinkText: { fontSize: 13, color: C.textSub },
  loginLinkAccent: { color: C.primary, fontWeight: '700' },
  disclaimer: { fontSize: 11, color: C.textMuted, textAlign: 'center', lineHeight: 17, paddingHorizontal: 8 },
});
