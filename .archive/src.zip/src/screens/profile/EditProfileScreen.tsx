﻿import React, { useEffect, useRef, useState } from 'react';
import {
  Alert,
  Animated,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Text } from 'react-native-paper';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import Svg, { Path, Circle } from 'react-native-svg';
import type { RootNavProp } from '@/navigation/types';
import { useAuthStore } from '@/store/authStore';
import { updateUser } from '@/services/firebase/userService';
import { isValidName, isValidPhoneNumber } from '@/utils/validators';

const C = {
  bg: '#F4F6FB',
  card: '#FFFFFF',
  border: '#E8ECF4',
  borderFocus: '#7C3AED',
  primary: '#7C3AED',
  text: '#111827',
  textSub: '#6B7280',
  textMuted: '#9CA3AF',
  error: '#DC2626',
  errorBg: '#FEF2F2',
  errorBorder: '#FECACA',
};

// â”€â”€â”€ Icons â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const IconBack = () => (
  <Svg width={20} height={20} viewBox="0 0 24 24" fill="none">
    <Path d="M19 12H5M5 12l7 7M5 12l7-7" stroke={C.primary} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconUser = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Circle cx="12" cy="8" r="4" stroke={C.textMuted} strokeWidth="1.8" />
    <Path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" stroke={C.textMuted} strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);
const IconPhone = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.8 19.79 19.79 0 01.1 1.18 2 2 0 012.1 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 14.92v2z" stroke={C.textMuted} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconDept = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M4 20h16M6 20V8l6-4 6 4v12M9 10h.01M15 10h.01M9 14h.01M15 14h.01" stroke={C.textMuted} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconChevron = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M9 6l6 6-6 6" stroke={C.textMuted} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

const DEPARTMENTS = [
  'CSE - Computer Science and Engineering',
  'EEE - Electrical and Electronic Engineering',
  'BBA - Business Administration',
  'English - English',
  'Law - Law',
  'Pharmacy - Pharmacy',
  'Economics - Economics',
  'Architecture - Architecture',
];

// â”€â”€â”€ Input field â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function Field({
  label, value, onChangeText, icon, placeholder, keyboardType, autoCapitalize, error,
}: {
  label: string; value: string; onChangeText: (t: string) => void;
  icon: React.ReactNode; placeholder?: string; error?: string;
  keyboardType?: 'default' | 'phone-pad' | 'email-address';
  autoCapitalize?: 'none' | 'words' | 'sentences';
}) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={fi.wrap}>
      <Text style={fi.label}>{label}</Text>
      <View style={[fi.row, focused && fi.rowFocus, !!error && fi.rowError]}>
        <View style={fi.icon}>{icon}</View>
        <TextInput
          style={fi.input}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={C.textMuted}
          keyboardType={keyboardType ?? 'default'}
          autoCapitalize={autoCapitalize ?? 'sentences'}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
        />
      </View>
      {!!error && <Text style={fi.error}>{error}</Text>}
    </View>
  );
}

const fi = StyleSheet.create({
  wrap:     { marginBottom: 14 },
  label:    { fontSize: 12, fontWeight: '700', color: C.textSub, letterSpacing: 0.4, marginBottom: 6, textTransform: 'uppercase' },
  row:      { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: 14, borderWidth: 1, borderColor: C.border, height: 52, paddingHorizontal: 14, gap: 10 },
  rowFocus: { borderColor: C.borderFocus, backgroundColor: 'rgba(124,58,237,0.03)' },
  rowError: { borderColor: C.error, backgroundColor: C.errorBg },
  icon:     { width: 22, alignItems: 'center' },
  input:    { flex: 1, fontSize: 15, color: C.text, fontWeight: '500' },
  error:    { fontSize: 11, color: C.error, marginTop: 4, marginLeft: 4 },
});

// â”€â”€â”€ Department picker row â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function DeptPicker({ value, onPress, error }: { value: string; onPress: () => void; error?: string }) {
  return (
    <View style={fi.wrap}>
      <Text style={fi.label}>Department</Text>
      <TouchableOpacity style={[fi.row, !!error && fi.rowError]} onPress={onPress} activeOpacity={0.7}>
        <View style={fi.icon}><IconDept /></View>
        <Text style={[{ flex: 1, fontSize: 15, fontWeight: '500' }, value ? { color: C.text } : { color: C.textMuted }]} numberOfLines={1}>
          {value || 'Select your department'}
        </Text>
        <IconChevron />
      </TouchableOpacity>
      {!!error && <Text style={fi.error}>{error}</Text>}
    </View>
  );
}

// â”€â”€â”€ Main screen â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export default function EditProfileScreen() {
  const navigation = useNavigation<RootNavProp>();
  const insets     = useSafeAreaInsets();
  const { user, setUser } = useAuthStore();

  const [name, setName]           = useState('');
  const [phone, setPhone]         = useState('');
  const [department, setDepartment] = useState('');
  const [showDeptPicker, setShowDeptPicker] = useState(false);
  const [loading, setLoading]     = useState(false);
  const [errors, setErrors]       = useState<Record<string, string>>({});
  const btnScale = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    setName(user?.name ?? '');
    setPhone(user?.phoneNumber ?? '');
    setDepartment(user?.department ?? '');
  }, [user]);

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!isValidName(name)) errs.name = 'Please enter your full name';
    if (phone.trim() && !isValidPhoneNumber(phone)) errs.phone = 'Enter a valid phone number';
    if (!department.trim()) errs.department = 'Please select a department';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSave = async () => {
    if (!validate() || !user?.uid) return;
    setLoading(true);
    try {
      const updated = await updateUser(user.uid, {
        name: name.trim(),
        phoneNumber: phone.trim(),
        department: department.split(' - ')[0].trim(),
      });
      setUser(updated);
      Alert.alert('Saved', 'Your profile has been updated.');
      navigation.goBack();
    } catch (e: any) {
      Alert.alert('Error', e.message ?? 'Could not save. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const pressIn  = () => Animated.spring(btnScale, { toValue: 0.97, useNativeDriver: true, tension: 120 }).start();
  const pressOut = () => Animated.spring(btnScale, { toValue: 1,    useNativeDriver: true, tension: 80  }).start();

  return (
    <View style={[s.root, { paddingTop: insets.top }]}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>

          {/* Top bar */}
          <View style={s.topBar}>
            <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()} activeOpacity={0.7}>
              <IconBack />
            </TouchableOpacity>
            <Text style={s.heading}>Edit Profile</Text>
            <View style={{ width: 36 }} />
          </View>

          {/* Avatar preview */}
          <View style={s.avatarSection}>
            <View style={s.avatarCircle}>
              <Text style={s.avatarLetter}>{(name || user?.name || 'U').charAt(0).toUpperCase()}</Text>
            </View>
            <Text style={s.avatarName}>{name || user?.name || 'Your Name'}</Text>
            <Text style={s.avatarEmail}>{user?.email ?? ''}</Text>
          </View>

          {/* Form */}
          <View style={s.card}>
            <Field
              label="Full Name"
              value={name}
              onChangeText={setName}
              icon={<IconUser />}
              placeholder="e.g. Mozahid Rahman"
              autoCapitalize="words"
              error={errors.name}
            />
            <Field
              label="Phone Number"
              value={phone}
              onChangeText={setPhone}
              icon={<IconPhone />}
              placeholder="e.g. 01XXXXXXXXX"
              keyboardType="phone-pad"
              autoCapitalize="none"
              error={errors.phone}
            />
            <DeptPicker value={department} onPress={() => setShowDeptPicker(true)} error={errors.department} />
          </View>

          {/* Save button */}
          <Animated.View style={{ transform: [{ scale: btnScale }], paddingHorizontal: 20 }}>
            <Pressable
              style={[s.saveBtn, loading && { opacity: 0.6 }]}
              onPress={handleSave}
              onPressIn={pressIn}
              onPressOut={pressOut}
              disabled={loading}
            >
              <Text style={s.saveTxt}>{loading ? 'Saving...' : 'Save Changes'}</Text>
            </Pressable>
          </Animated.View>

        </ScrollView>
      </KeyboardAvoidingView>

      {/* Department picker modal */}
      {showDeptPicker && (
        <Pressable style={s.overlay} onPress={() => setShowDeptPicker(false)}>
          <Pressable style={s.deptSheet} onPress={(e) => e.stopPropagation()}>
            <View style={s.sheetHandle} />
            <Text style={s.sheetTitle}>Select Department</Text>
            {DEPARTMENTS.map((dept) => {
              const active = department.startsWith(dept.split(' - ')[0]);
              return (
                <TouchableOpacity
                  key={dept}
                  style={[s.deptRow, active && s.deptRowActive]}
                  onPress={() => { setDepartment(dept); setShowDeptPicker(false); }}
                  activeOpacity={0.7}
                >
                  <Text style={[s.deptTxt, active && s.deptTxtActive]}>{dept}</Text>
                  {active && <Text style={{ color: C.primary, fontSize: 16 }}>✓</Text>}
                </TouchableOpacity>
              );
            })}
          </Pressable>
        </Pressable>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root:   { flex: 1, backgroundColor: C.bg },
  scroll: { paddingBottom: 40 },

  topBar:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12 },
  backBtn:  { width: 36, height: 36, borderRadius: 10, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  heading:  { fontSize: 17, fontWeight: '800', color: C.text },

  avatarSection: { alignItems: 'center', paddingVertical: 24, gap: 6 },
  avatarCircle:  { width: 80, height: 80, borderRadius: 40, backgroundColor: 'rgba(124,58,237,0.12)', borderWidth: 2, borderColor: 'rgba(124,58,237,0.3)', alignItems: 'center', justifyContent: 'center' },
  avatarLetter:  { fontSize: 32, fontWeight: '900', color: C.primary },
  avatarName:    { fontSize: 18, fontWeight: '800', color: C.text },
  avatarEmail:   { fontSize: 12, color: C.textMuted },

  card:    { marginHorizontal: 16, backgroundColor: C.card, borderRadius: 20, borderWidth: 1, borderColor: C.border, padding: 20, marginBottom: 20, shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 8, shadowOffset: { width: 0, height: 2 }, elevation: 1 },

  saveBtn: { height: 54, borderRadius: 16, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  saveTxt: { fontSize: 16, fontWeight: '800', color: '#fff', letterSpacing: -0.2 },

  overlay:   { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  deptSheet: { backgroundColor: C.card, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 36 },
  sheetHandle: { width: 36, height: 4, borderRadius: 2, backgroundColor: '#E5E7EB', alignSelf: 'center', marginBottom: 16 },
  sheetTitle:  { fontSize: 17, fontWeight: '800', color: C.text, marginBottom: 14 },
  deptRow:     { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 13, paddingHorizontal: 14, borderRadius: 12, marginBottom: 6, backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: C.border },
  deptRowActive: { backgroundColor: 'rgba(124,58,237,0.07)', borderColor: 'rgba(124,58,237,0.3)' },
  deptTxt:     { fontSize: 14, color: C.textSub, fontWeight: '600' },
  deptTxtActive: { color: C.primary, fontWeight: '700' },
});


