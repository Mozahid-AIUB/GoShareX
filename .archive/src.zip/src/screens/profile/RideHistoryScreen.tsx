import React, { useCallback, useEffect, useState } from 'react';
import { View, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import {
  collection, query, where, orderBy, getDocs,
  limit, startAfter, QueryDocumentSnapshot, DocumentData,
} from 'firebase/firestore';
import { db } from '@/config/firebase.config';
import { useAuthStore } from '@/store/authStore';

const PAGE_SIZE = 20;

interface RideRecord {
  id: string;
  destination: string;
  splitAmount: number;
  status: string;
  confirmedAt: number;
  rider1Name: string;
  rider2Name: string;
  rider1: string;
  rider2: string;
}

export default function RideHistoryScreen() {
  const { user } = useAuthStore();
  const [rides, setRides] = useState<RideRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastDoc, setLastDoc] = useState<QueryDocumentSnapshot<DocumentData> | null>(null);
  const [hasMore, setHasMore] = useState(true);

  const fetchPage = useCallback(async (after: QueryDocumentSnapshot<DocumentData> | null) => {
    if (!user?.uid) return;

    const makeQuery = (field: 'rider1' | 'rider2') =>
      after
        ? query(collection(db, 'rides'), where(field, '==', user.uid), orderBy('confirmedAt', 'desc'), startAfter(after), limit(PAGE_SIZE))
        : query(collection(db, 'rides'), where(field, '==', user.uid), orderBy('confirmedAt', 'desc'), limit(PAGE_SIZE));

    const [snap1, snap2] = await Promise.all([
      getDocs(makeQuery('rider1')),
      getDocs(makeQuery('rider2')),
    ]);

    const toRecords = (snap: typeof snap1): RideRecord[] =>
      snap.docs.map((d) => ({ id: d.id, ...d.data() } as RideRecord));

    const combined = [...toRecords(snap1), ...toRecords(snap2)]
      .sort((a, b) => b.confirmedAt - a.confirmedAt);

    // Use the last doc from whichever snapshot had more results for cursor
    const newLastDoc =
      snap1.docs.length >= snap2.docs.length
        ? snap1.docs[snap1.docs.length - 1] ?? null
        : snap2.docs[snap2.docs.length - 1] ?? null;

    setLastDoc(newLastDoc ?? null);
    setHasMore(snap1.docs.length === PAGE_SIZE || snap2.docs.length === PAGE_SIZE);
    return combined;
  }, [user?.uid]);

  useEffect(() => {
    if (!user?.uid) return;
    setLoading(true);
    fetchPage(null)
      .then((records) => { if (records) setRides(records); })
      .catch(() => setError('Ride history লোড করা যায়নি।'))
      .finally(() => setLoading(false));
  }, [user?.uid, fetchPage]);

  const loadMore = async () => {
    if (!hasMore || loadingMore || !lastDoc) return;
    setLoadingMore(true);
    try {
      const more = await fetchPage(lastDoc);
      if (more) setRides((prev) => [...prev, ...more]);
    } catch {
      setError('আরো ride লোড করা যায়নি।');
    } finally {
      setLoadingMore(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#6C63FF" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={rides}
        keyExtractor={(r) => r.id}
        renderItem={({ item }) => {
          const partnerName = item.rider1 === user?.uid ? item.rider2Name : item.rider1Name;
          return (
            <View style={styles.rideCard}>
              <Text style={styles.dest}>🛺 {item.destination}</Text>
              <Text style={styles.meta}>Partner: {partnerName ?? '—'}</Text>
              <Text style={styles.amount}>💰 ৳{item.splitAmount} saved</Text>
              <Text style={[styles.status, { color: item.status === 'completed' ? '#34A853' : '#EA4335' }]}>
                {item.status}
              </Text>
            </View>
          );
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={{ fontSize: 40 }}>🛺</Text>
            <Text style={{ color: '#9E9E9E', marginTop: 10 }}>কোনো ride history নেই</Text>
          </View>
        }
        ListFooterComponent={
          hasMore ? (
            <TouchableOpacity style={styles.loadMoreBtn} onPress={loadMore} disabled={loadingMore}>
              {loadingMore
                ? <ActivityIndicator size="small" color="#6C63FF" />
                : <Text style={styles.loadMoreText}>আরো দেখুন</Text>}
            </TouchableOpacity>
          ) : null
        }
        contentContainerStyle={{ padding: 14, gap: 10 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8F9FA' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#F8F9FA' },
  errorText: { color: '#EA4335', fontSize: 15, textAlign: 'center', padding: 20 },
  rideCard: { backgroundColor: '#fff', borderRadius: 14, padding: 14, elevation: 2, gap: 4 },
  dest: { fontSize: 16, fontWeight: '700', color: '#202124' },
  meta: { fontSize: 13, color: '#666' },
  amount: { fontSize: 14, fontWeight: '600', color: '#34A853' },
  status: { fontSize: 12, fontWeight: '600', textTransform: 'capitalize' },
  empty: { alignItems: 'center', marginTop: 80 },
  loadMoreBtn: { alignItems: 'center', paddingVertical: 16 },
  loadMoreText: { color: '#6C63FF', fontWeight: '700', fontSize: 14 },
});
