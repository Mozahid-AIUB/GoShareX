import React, { useState } from 'react';
import {
  Alert,
  Linking,
  ScrollView,
  StyleSheet,
  Switch,
  TouchableOpacity,
  View,
} from 'react-native';
import { Text } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Circle, Path, Rect } from 'react-native-svg';

import type { RootNavProp } from '@/navigation/types';
import { useAuthStore } from '@/store/authStore';
import authService from '@/services/firebase/authService';

// ─── Finova glossy design tokens ────────────────────────────────────────────
const C = {
  bg: '#07090F',
  surface: 'rgba(255,255,255,0.055)',
  border: 'rgba(255,255,255,0.09)',
  borderStrong: 'rgba(255,255,255,0.15)',
  primary: '#7C6FF7',
  teal: '#14B8A6',
  amber: '#F59E0B',
  red: '#F43F5E',
  green: '#10B981',
  text: '#EEF2FF',
  textSub: '#7B8DB0',
  textMuted: '#343D55',
  white: '#FFFFFF',
  purple: '#A78BFA',
};

const SPONSORSHIP_EMAIL = 'sponsorship@gosharex.app';
const PRIVACY_URL = 'https://gosharex.app/privacy';
const TERMS_URL = 'https://gosharex.app/terms';

// ─── SVG Icons ────────────────────────────────────────────────────────────────
const IconBell = ({ color = C.purple }: { color?: string }) => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconMap = ({ color = C.teal }: { color?: string }) => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconUser = ({ color = C.purple }: { color?: string }) => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Circle cx="12" cy="8" r="4" stroke={color} strokeWidth="1.8" />
    <Path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);
const IconShield = ({ color = C.green }: { color?: string }) => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);
const IconMail = ({ color = C.amber }: { color?: string }) => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" stroke={color} strokeWidth="1.8" />
    <Path d="M22 6l-10 7L2 6" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);
const IconGavel = ({ color = C.red }: { color?: string }) => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M14 2l8 8-4 4-8-8 4-4zM10 14l-7 7M3 21l7-7" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconLock = ({ color = C.textSub }: { color?: string }) => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Rect x="3" y="11" width="18" height="11" rx="2" stroke={color} strokeWidth="1.8" />
    <Path d="M7 11V7a5 5 0 0110 0v4" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);
const IconLogout = () => (
  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
    <Path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" stroke={C.red} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconChevron = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
    <Path d="M9 18l6-6-6-6" stroke={C.textMuted} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconExternal = () => (
  <Svg width={14} height={14} viewBox="0 0 24 24" fill="none">
    <Path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3" stroke={C.textMuted} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

// ─── Sub-components ───────────────────────────────────────────────────────────
const SectionHeader = ({ label }: { label: string }) => (
  <Text style={s.sectionHeader}>{label}</Text>
);

const ToggleRow = ({
  icon, label, sub, value, onChange,
}: { icon: React.ReactNode; label: string; sub?: string; value: boolean; onChange: (v: boolean) => void }) => (
  <View style={s.row}>
    <View style={s.rowIcon}>{icon}</View>
    <View style={s.rowInfo}>
      <Text style={s.rowLabel}>{label}</Text>
      {sub && <Text style={s.rowSub}>{sub}</Text>}
    </View>
    <Switch
      value={value}
      onValueChange={onChange}
      trackColor={{ false: 'rgba(255,255,255,0.1)', true: C.primary }}
      thumbColor={C.white}
    />
  </View>
);

const LinkRow = ({
  icon, label, sub, onPress, accent,
}: { icon: React.ReactNode; label: string; sub?: string; onPress: () => void; accent?: boolean }) => (
  <TouchableOpacity style={s.row} onPress={onPress} activeOpacity={0.75}>
    <View style={s.rowIcon}>{icon}</View>
    <View style={s.rowInfo}>
      <Text style={[s.rowLabel, accent && { color: C.primary }]}>{label}</Text>
      {sub && <Text style={s.rowSub}>{sub}</Text>}
    </View>
    <IconChevron />
  </TouchableOpacity>
);

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function SettingsScreen() {
  const navigation = useNavigation<RootNavProp>();
  const insets = useSafeAreaInsets();
  const { user, logout } = useAuthStore();

  const [notifRides, setNotifRides] = useState(true);
  const [notifChat, setNotifChat] = useState(true);
  const [locationBg, setLocationBg] = useState(true);
  const [shareAnonymous, setShareAnonymous] = useState(false);

  const handleLogout = async () => {
    Alert.alert('Sign out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign out', style: 'destructive', onPress: async () => {
          try { await authService.logout(); } finally {
            logout();
            // AppNavigator will automatically switch to Auth stack when isAuthenticated becomes false
          }
        }
      },
    ]);
  };

  const openLink = (url: string) => Linking.openURL(url).catch(() => Alert.alert('Error', 'Could not open link.'));

  const handleSponsor = () => {
    Linking.openURL(`mailto:${SPONSORSHIP_EMAIL}?subject=GoShareX Sponsorship Inquiry`)
      .catch(() => Alert.alert('Sponsorship', `Please email us at:\n${SPONSORSHIP_EMAIL}`));
  };

  return (
    <View style={[s.root, { paddingTop: insets.top }]}>
      <View style={s.radial1} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}>

        {/* Profile card */}
        <View style={s.profileCard}>
          <View style={s.profileAvatar}>
            <Text style={s.profileAvatarText}>{(user?.name ?? 'U').charAt(0).toUpperCase()}</Text>
          </View>
          <View style={s.profileInfo}>
            <Text style={s.profileName}>{user?.name ?? 'GoShareX User'}</Text>
            <Text style={s.profileEmail}>{user?.email ?? ''}</Text>
            <Text style={s.profileId}>{user?.department ?? 'No department set'}</Text>
          </View>
          <TouchableOpacity
            style={s.editBtn}
            onPress={() => navigation.navigate('EditProfile')}
            activeOpacity={0.8}
          >
            <Text style={s.editBtnText}>Edit</Text>
          </TouchableOpacity>
        </View>

        {/* Notifications */}
        <SectionHeader label="Notifications" />
        <View style={s.card}>
          <ToggleRow icon={<IconBell />} label="Ride requests" sub="Alert when a rider wants to share" value={notifRides} onChange={setNotifRides} />
          <View style={s.rowDivider} />
          <ToggleRow icon={<IconBell color={C.teal} />} label="Chat messages" sub="New message alerts" value={notifChat} onChange={setNotifChat} />
        </View>

        {/* Location */}
        <SectionHeader label="Location & Privacy" />
        <View style={s.card}>
          <ToggleRow icon={<IconMap />} label="Background location" sub="Required for real-time ride matching" value={locationBg} onChange={setLocationBg} />
          <View style={s.rowDivider} />
          <ToggleRow icon={<IconShield />} label="Anonymous mode" sub="Hide your identity in group chats" value={shareAnonymous} onChange={setShareAnonymous} />
        </View>

        {/* Account */}
        <SectionHeader label="Account" />
        <View style={s.card}>
          <View style={s.row}>
            <View style={s.rowIcon}><IconUser /></View>
            <View style={s.rowInfo}>
              <Text style={s.rowLabel}>Email</Text>
              <Text style={s.rowSub}>{user?.email ?? '—'}</Text>
            </View>
          </View>
          <View style={s.rowDivider} />
          <View style={s.row}>
            <View style={s.rowIcon}><IconLock /></View>
            <View style={s.rowInfo}>
              <Text style={s.rowLabel}>Department</Text>
              <Text style={s.rowSub}>{user?.department ?? '—'}</Text>
            </View>
          </View>
        </View>

        {/* Legal & Compliance */}
        <SectionHeader label="Legal & Compliance" />
        <View style={s.card}>
          <LinkRow
            icon={<IconGavel />}
            label="Terms of Service"
            sub="Financial disclaimer included"
            onPress={() => openLink(TERMS_URL)}
          />
          <View style={s.rowDivider} />
          <LinkRow
            icon={<IconShield color={C.teal} />}
            label="Privacy Policy"
            sub="How we handle your data"
            onPress={() => openLink(PRIVACY_URL)}
          />
        </View>

        {/* Financial Disclaimer */}
        <View style={s.disclaimerCard}>
          <View style={s.disclaimerHeader}>
            <IconGavel color={C.amber} />
            <Text style={s.disclaimerTitle}>Financial Disclaimer</Text>
          </View>
          <Text style={s.disclaimerBody}>
            GoShareX is a ride-sharing coordination platform.
            We facilitate connections between riders — we are{' '}
            <Text style={s.disclaimerBold}>not responsible for any financial loss</Text>,
            fare disputes, payment issues, or monetary damages arising between riders or with vehicle drivers.
            All financial agreements are strictly between the users involved.
            By using GoShareX, you agree to resolve all monetary matters directly with other parties.
          </Text>
        </View>

        {/* Sponsorship */}
        <SectionHeader label="Support & Sponsorship" />
        <View style={s.card}>
          <LinkRow
            icon={<IconMail />}
            label="Become a Sponsor"
            sub={`Contact us at ${SPONSORSHIP_EMAIL}`}
            onPress={handleSponsor}
            accent
          />
        </View>

        {/* App info */}
        <View style={s.appInfoRow}>
          <Text style={s.appInfoText}>GoShareX · v1.0.0</Text>
          <Text style={s.appInfoText}>Made with care 🛺</Text>
        </View>

        {/* Logout */}
        <TouchableOpacity style={s.logoutBtn} onPress={handleLogout} activeOpacity={0.85}>
          <IconLogout />
          <Text style={s.logoutText}>Sign Out</Text>
        </TouchableOpacity>

      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  radial1: {
    position: 'absolute', top: -80, right: -60,
    width: 240, height: 240, borderRadius: 120,
    backgroundColor: 'rgba(124,111,247,0.1)',
  },

  // Profile
  profileCard: {
    margin: 16, marginTop: 8,
    flexDirection: 'row', alignItems: 'center', gap: 14,
    backgroundColor: 'rgba(124,111,247,0.09)',
    borderWidth: 1, borderColor: 'rgba(124,111,247,0.22)',
    borderRadius: 24, padding: 16,
  },
  profileAvatar: {
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: 'rgba(124,111,247,0.2)',
    borderWidth: 2, borderColor: 'rgba(124,111,247,0.4)',
    alignItems: 'center', justifyContent: 'center',
  },
  profileAvatarText: { fontSize: 22, fontWeight: '900', color: C.text },
  profileInfo: { flex: 1, gap: 2 },
  profileName: { fontSize: 16, fontWeight: '800', color: C.text },
  profileEmail: { fontSize: 12, color: C.textSub },
  profileId: { fontSize: 11, color: C.textMuted },
  editBtn: {
    backgroundColor: 'rgba(124,111,247,0.15)',
    borderRadius: 12, paddingHorizontal: 14, paddingVertical: 7,
    borderWidth: 1, borderColor: 'rgba(124,111,247,0.3)',
  },
  editBtnText: { fontSize: 12, fontWeight: '700', color: C.purple },

  // Sections
  sectionHeader: {
    fontSize: 10, fontWeight: '800', color: C.textSub,
    letterSpacing: 1.2, textTransform: 'uppercase',
    marginHorizontal: 20, marginTop: 20, marginBottom: 8,
  },
  card: {
    marginHorizontal: 16,
    backgroundColor: C.surface,
    borderWidth: 1, borderColor: C.border,
    borderRadius: 20, overflow: 'hidden',
  },
  row: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 13, gap: 12,
  },
  rowIcon: {
    width: 34, height: 34, borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.05)',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: C.border,
  },
  rowInfo: { flex: 1 },
  rowLabel: { fontSize: 14, fontWeight: '700', color: C.text },
  rowSub: { fontSize: 11, color: C.textSub, marginTop: 2 },
  rowDivider: { height: 1, backgroundColor: C.border, marginLeft: 62 },

  // Disclaimer
  disclaimerCard: {
    marginHorizontal: 16, marginTop: 14,
    backgroundColor: 'rgba(245,158,11,0.07)',
    borderWidth: 1, borderColor: 'rgba(245,158,11,0.2)',
    borderRadius: 20, padding: 16,
  },
  disclaimerHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  disclaimerTitle: { fontSize: 13, fontWeight: '800', color: C.amber },
  disclaimerBody: { fontSize: 12, color: '#A8946B', lineHeight: 20 },
  disclaimerBold: { fontWeight: '800', color: C.amber },

  // App info
  appInfoRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    marginHorizontal: 20, marginTop: 20,
  },
  appInfoText: { fontSize: 11, color: C.textMuted },

  // Logout
  logoutBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    marginHorizontal: 16, marginTop: 16,
    height: 52, borderRadius: 18,
    backgroundColor: 'rgba(244,63,94,0.1)',
    borderWidth: 1, borderColor: 'rgba(244,63,94,0.25)',
  },
  logoutText: { fontSize: 15, fontWeight: '800', color: C.red },
});
