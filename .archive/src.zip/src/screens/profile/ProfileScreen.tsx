import React, { useEffect, useRef, useState } from 'react';
import {
  Alert,
  Animated,
  Dimensions,
  Linking,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Text } from 'react-native-paper';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { useBottomTabBarHeight } from '@react-navigation/bottom-tabs';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Path } from 'react-native-svg';
import type { MainTabNavProp } from '@/navigation/types';

import authService from '@/services/firebase/authService';
import { getUser } from '@/services/firebase/userService';
import { getTrustBreakdown, RATING_CATEGORIES, type TrustBreakdown } from '@/services/firebase/ratingService';
import { useAuthStore } from '@/store/authStore';
import type { User } from '@/types/auth.types';

const SW = Dimensions.get('window').width;

// ─── Design tokens ────────────────────────────────────────────────────────────
const C = {
  bg: '#F4F6FB',
  card: '#FFFFFF',
  cardBorder: '#E8ECF4',
  primary: '#7C3AED',
  primaryDim: 'rgba(124,58,237,0.08)',
  teal: '#059669',
  tealDim: 'rgba(5,150,105,0.09)',
  amber: '#D97706',
  amberDim: 'rgba(217,119,6,0.09)',
  blue: '#4F46E5',
  blueDim: 'rgba(79,70,229,0.09)',
  pink: '#DB2777',
  pinkDim: 'rgba(219,39,119,0.09)',
  red: '#DC2626',
  text: '#111827',
  textSub: '#6B7280',
  textMuted: '#9CA3AF',
  white: '#FFFFFF',
  surface: '#F9FAFB',
};

const BADGE_META: Record<string, { color: string; next?: string; ridesNeeded?: number; emoji: string }> = {
  'New Rider':  { color: '#9CA3AF', next: 'Regular',  ridesNeeded: 6,   emoji: '🌱' },
  'Regular':    { color: '#34D399', next: 'Trusted',  ridesNeeded: 21,  emoji: '🚀' },
  'Trusted':    { color: '#818CF8', next: 'Elite',    ridesNeeded: 51,  emoji: '💎' },
  'Elite Rider':{ color: '#C084FC', emoji: '👑' },
  'Unreliable': { color: '#F87171', emoji: '⚠️' },
};

const SUPPORT_EMAIL = 'mozahidislam343@gmail.com';

// ─── SVG Icons ────────────────────────────────────────────────────────────────
const IconEdit = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
    <Path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" stroke={C.textSub} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" stroke={C.textSub} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconHistory = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
    <Path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" stroke={C.textSub} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconSettings = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
    <Path d="M12 15a3 3 0 100-6 3 3 0 000 6z" stroke={C.textSub} strokeWidth="2" strokeLinecap="round" />
    <Path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" stroke={C.textSub} strokeWidth="2" strokeLinecap="round" />
  </Svg>
);
const IconAlert = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
    <Path d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" stroke={C.pink} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconStar = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill={C.amber}>
    <Path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
  </Svg>
);
const IconChevron = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
    <Path d="M9 18l6-6-6-6" stroke={C.textMuted} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconLogout = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
    <Path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" stroke={C.red} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconMail = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
    <Path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" stroke={C.amber} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Path d="M22 6l-10 7L2 6" stroke={C.amber} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconShield = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
    <Path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke={C.teal} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const IconRide = () => (
  <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
    <Path d="M5 17H3a2 2 0 01-2-2V5a2 2 0 012-2h11a2 2 0 012 2v3" stroke={C.blue} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Path d="M9 17h6m4 0h2M7 17a2 2 0 100-4 2 2 0 000 4zm10 0a2 2 0 100-4 2 2 0 000 4z" stroke={C.blue} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Path d="M13 11h8l-2 4" stroke={C.blue} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

// ─── Trust breakdown card ─────────────────────────────────────────────────────
const CAT_KEYS: Record<string, keyof TrustBreakdown> = {
  punctual:    'punctualPct',
  friendly:    'friendlyPct',
  tidy:        'tidyPct',
  respectful:  'respectfulPct',
  safeRide:    'safeRidePct',
};

function TrustCard({ breakdown }: { breakdown: TrustBreakdown }) {
  const scoreColor = breakdown.trustScore >= 80 ? C.teal : breakdown.trustScore >= 60 ? C.amber : C.pink;

  return (
    <View style={tc.wrap}>
      {/* Header row */}
      <View style={tc.header}>
        <View>
          <Text style={tc.title}>Trust Score</Text>
          <Text style={tc.sub}>Based on {breakdown.totalRatings} anonymous ratings</Text>
        </View>
        <View style={[tc.scoreBadge, { borderColor: `${scoreColor}40`, backgroundColor: `${scoreColor}10` }]}>
          <Text style={[tc.scoreNum, { color: scoreColor }]}>{breakdown.trustScore}</Text>
          <Text style={[tc.scoreOf, { color: scoreColor }]}>/100</Text>
        </View>
      </View>

      {/* Star avg */}
      <View style={tc.starRow}>
        {[1,2,3,4,5].map((s) => (
          <Text key={s} style={{ fontSize: 16, opacity: s <= Math.round(breakdown.avgStars) ? 1 : 0.2 }}>⭐</Text>
        ))}
        <Text style={tc.starNum}>{breakdown.avgStars.toFixed(1)}</Text>
      </View>

      {/* Category bars */}
      <View style={tc.cats}>
        {RATING_CATEGORIES.map((cat) => {
          const pct = (breakdown[CAT_KEYS[cat.id]] as number) ?? 0;
          const barColor = pct >= 80 ? C.teal : pct >= 60 ? C.amber : C.pink;
          return (
            <View key={cat.id} style={tc.catRow}>
              <Text style={tc.catEmoji}>{cat.emoji}</Text>
              <Text style={tc.catLabel}>{cat.label}</Text>
              <View style={tc.barTrack}>
                <View style={[tc.barFill, { width: `${pct}%`, backgroundColor: barColor }]} />
              </View>
              <Text style={[tc.catPct, { color: barColor }]}>{pct}%</Text>
            </View>
          );
        })}
      </View>

      <Text style={tc.anonNote}>🔒 Individual raters are never revealed</Text>
    </View>
  );
}

// ─── Animated stat card ───────────────────────────────────────────────────────
function StatCard({ label, value, color, dim, icon, progress }: {
  label: string; value: string; color: string; dim: string; icon: React.ReactNode; progress?: number;
}) {
  const anim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(anim, { toValue: progress ?? 0, duration: 1100, useNativeDriver: false }).start();
  }, [progress, anim]);

  return (
    <View style={[sc.card, { borderColor: `${color}22`, backgroundColor: dim }]}>
      <View style={[sc.iconBox, { backgroundColor: `${color}18` }]}>{icon}</View>
      <Text style={[sc.val, { color }]}>{value}</Text>
      <Text style={sc.lbl}>{label}</Text>
      {progress !== undefined && (
        <View style={sc.bar}>
          <Animated.View style={[sc.fill, { backgroundColor: color, width: anim.interpolate({ inputRange: [0, 100], outputRange: ['0%', '100%'] }) }]} />
        </View>
      )}
    </View>
  );
}

// ─── Menu row ─────────────────────────────────────────────────────────────────
function MenuItem({ icon, label, sub, onPress, danger }: {
  icon: React.ReactNode; label: string; sub?: string; onPress: () => void; danger?: boolean;
}) {
  return (
    <TouchableOpacity style={mi.row} onPress={onPress} activeOpacity={0.7}>
      <View style={mi.iconWrap}>{icon}</View>
      <View style={mi.texts}>
        <Text style={[mi.label, danger && { color: C.red }]}>{label}</Text>
        {sub && <Text style={mi.sub}>{sub}</Text>}
      </View>
      <IconChevron />
    </TouchableOpacity>
  );
}

// ─── Report modal ─────────────────────────────────────────────────────────────
function ReportModal({ visible, onClose, userEmail }: { visible: boolean; onClose: () => void; userEmail?: string }) {
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);

  const send = async () => {
    if (!text.trim()) return;
    setBusy(true);
    const url = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent('GoShareX — Problem Report')}&body=${encodeURIComponent(`From: ${userEmail ?? 'unknown'}\n\n${text}`)}`;
    try {
      await Linking.openURL(url);
      setText('');
      onClose();
    } catch {
      Alert.alert('Error', 'Could not open email app.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={rm.overlay} onPress={onClose}>
        <Pressable style={rm.sheet} onPress={(e) => e.stopPropagation()}>
          <View style={rm.handle} />
          <Text style={rm.title}>Report a Problem</Text>
          <Text style={rm.sub}>We'll get back to you within 24 hours.</Text>
          <TextInput
            style={rm.input}
            placeholder="Describe what went wrong…"
            placeholderTextColor={C.textMuted}
            multiline
            numberOfLines={5}
            value={text}
            onChangeText={setText}
            editable={!busy}
          />
          <View style={rm.btnRow}>
            <TouchableOpacity style={rm.cancel} onPress={onClose}>
              <Text style={rm.cancelTxt}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[rm.send, (!text.trim() || busy) && rm.sendDim]} onPress={send} disabled={!text.trim() || busy}>
              <Text style={rm.sendTxt}>{busy ? 'Sending…' : 'Send'}</Text>
            </TouchableOpacity>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

// ─── Recoverable error check ──────────────────────────────────────────────────
function isRecoverable(err: unknown) {
  const s = String((err as any)?.code ?? '') + String((err as any)?.message ?? '');
  return /unavailable|deadline|precondition|network|offline|unstable/i.test(s);
}

// ─── Main screen ──────────────────────────────────────────────────────────────
export default function ProfileScreen() {
  const navigation = useNavigation<MainTabNavProp>();
  const tabBarHeight = useBottomTabBarHeight();
  const insets = useSafeAreaInsets();
  const { user, logout, setUser } = useAuthStore();
  const [profile, setProfile]         = useState<User | null>(user);
  const [breakdown, setBreakdown]     = useState<TrustBreakdown | null>(null);
  const [reportVisible, setReportVisible] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    setProfile(user);
  }, [user]);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
  }, [fadeAnim]);

  useFocusEffect(
    React.useCallback(() => {
      let active = true;
      if (!user?.uid) return () => { active = false; };
      getUser(user.uid).then((next) => {
        if (!active || !next) return;
        const merged = { ...next, profileStatus: 'live' as const, profileWarning: undefined };
        setProfile(merged);
        setUser(merged);
      }).catch((e) => { if (!isRecoverable(e)) console.warn('Profile refresh:', e); });
      getTrustBreakdown(user.uid).then((b) => { if (active && b) setBreakdown(b); }).catch(() => {});
      return () => { active = false; };
    }, [user?.uid, setUser])
  );

  const handleLogout = async () => {
    Alert.alert('Sign out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign out', style: 'destructive', onPress: async () => {
          try { await authService.logout(); } finally { logout(); }
        }
      },
    ]);
  };

  const openSponsor = () => {
    Linking.openURL(`mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent('GoShareX — Sponsorship / Partnership')}`).catch(() => {});
  };

  // ── Derived values ──
  const badge       = profile?.badge ?? 'New Rider';
  const badgeMeta   = BADGE_META[badge] ?? BADGE_META['New Rider'];
  const totalRides  = profile?.totalRides ?? 0;
  const rating      = profile?.rating ?? 5;
  const totalSaved  = profile?.totalSaved ?? 0;
  const completion  = profile?.completionRate ?? 100;
  const trustScore  = profile?.trustScore ?? 0;
  const strikes     = profile?.strikes ?? 0;
  const joinedAt    = profile?.createdAt ? new Date(profile.createdAt).toLocaleDateString('en-BD', { year: 'numeric', month: 'short' }) : '—';

  // Badge progress toward next tier
  const badgeProgress = (() => {
    if (badge === 'New Rider')  return Math.min((totalRides / 6)  * 100, 100);
    if (badge === 'Regular')    return Math.min(((totalRides - 6) / 15) * 100, 100);
    if (badge === 'Trusted')    return Math.min(((totalRides - 21) / 30) * 100, 100);
    return 100;
  })();

  const ridesLeft = badgeMeta.ridesNeeded ? Math.max(badgeMeta.ridesNeeded - totalRides, 0) : 0;

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <Animated.ScrollView
        style={{ flex: 1, opacity: fadeAnim }}
        contentContainerStyle={{ paddingBottom: tabBarHeight + 24, paddingHorizontal: 16, paddingTop: insets.top + 16 }}
        showsVerticalScrollIndicator={false}
      >

        {/* ── Hero card ── */}
        <View style={s.hero}>
          {/* Ambient glow blobs */}
          <View style={[s.glow, { top: -30, left: -20, backgroundColor: `${badgeMeta.color}18` }]} />
          <View style={[s.glow, { bottom: -40, right: -20, width: 160, height: 160, backgroundColor: 'rgba(5,150,105,0.06)' }]} />

          <View style={s.heroRow}>
            {/* Avatar */}
            <View style={s.avatarWrap}>
              <View style={[s.avatarRing, { borderColor: badgeMeta.color }]}>
                <View style={[s.avatarBg, { backgroundColor: `${badgeMeta.color}22` }]}>
                  <Text style={[s.avatarLetter, { color: badgeMeta.color }]}>
                    {(profile?.name ?? 'U').charAt(0).toUpperCase()}
                  </Text>
                </View>
              </View>
              <View style={s.onlineDot} />
            </View>

            {/* Info */}
            <View style={{ flex: 1 }}>
              <Text style={s.name}>{profile?.name ?? 'Student Rider'}</Text>
              <Text style={s.email} numberOfLines={1}>{profile?.email ?? '—'}</Text>

              <View style={s.badgeRow}>
                <View style={[s.badgePill, { backgroundColor: `${badgeMeta.color}18`, borderColor: `${badgeMeta.color}40` }]}>
                  <Text style={s.badgeEmoji}>{badgeMeta.emoji}</Text>
                  <Text style={[s.badgeLabel, { color: badgeMeta.color }]}>{badge}</Text>
                </View>
                <View style={s.ratingPill}>
                  <IconStar />
                  <Text style={s.ratingTxt}>{rating.toFixed(1)}</Text>
                </View>
              </View>

              <Text style={s.joinedTxt}>Member since {joinedAt}</Text>
            </View>
          </View>

          {/* Badge progress */}
          {badge !== 'Elite Rider' && badge !== 'Unreliable' && (
            <View style={s.progressSection}>
              <View style={s.progressLabelRow}>
                <Text style={s.progressLabel}>Progress to {badgeMeta.next}</Text>
                <Text style={[s.progressPct, { color: badgeMeta.color }]}>
                  {ridesLeft > 0 ? `${ridesLeft} rides left` : 'Almost there!'}
                </Text>
              </View>
              <View style={s.progressTrack}>
                <View style={[s.progressFill, { width: `${badgeProgress}%`, backgroundColor: badgeMeta.color }]} />
              </View>
            </View>
          )}

          {/* Quick numbers */}
          <View style={s.quickRow}>
            {[
              { val: String(totalRides),                                          lbl: 'Rides' },
              { val: `৳${totalSaved}`,                                           lbl: 'Saved' },
              { val: `${completion}%`,                                            lbl: 'Done' },
              { val: breakdown ? `${breakdown.trustScore}` : trustScore > 0 ? `${trustScore}` : '—', lbl: 'Trust' },
            ].map((item, i) => (
              <View key={i} style={[s.quickItem, i > 0 && s.quickBorder]}>
                <Text style={s.quickVal}>{item.val}</Text>
                <Text style={s.quickLbl}>{item.lbl}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* ── Stats grid ── */}
        <View style={s.grid}>
          <StatCard label="Trust Score"  value={`${trustScore}/100`}  color={C.teal}  dim={C.tealDim}  icon={<IconShield />}  progress={trustScore} />
          <StatCard label="Completion"   value={`${completion}%`}     color={C.amber} dim={C.amberDim} icon={<IconHistory />} progress={completion} />
          <StatCard label="Rating"       value={rating.toFixed(1)}    color={C.pink}  dim={C.pinkDim}  icon={<IconStar />}    progress={(rating / 5) * 100} />
          <StatCard label="Total Rides"  value={String(totalRides)}   color={C.blue}  dim={C.blueDim}  icon={<IconRide />}    progress={Math.min((totalRides / 100) * 100, 100)} />
        </View>

        {/* ── Trust breakdown (only shows after first rating received) ── */}
        {breakdown && breakdown.totalRatings > 0 && <TrustCard breakdown={breakdown} />}

        {/* ── Strikes warning (if any) ── */}
        {strikes > 0 && (
          <View style={s.strikeBanner}>
            <IconAlert />
            <Text style={s.strikeTxt}>
              {strikes} strike{strikes > 1 ? 's' : ''} on your account.{strikes >= 2 ? ' One more may lead to suspension.' : ''}
            </Text>
          </View>
        )}

        {/* ── Account section ── */}
        <View style={s.section}>
          <Text style={s.sectionTitle}>Account</Text>
          <MenuItem icon={<IconEdit />}     label="Edit Profile"   sub="Name, photo, department"  onPress={() => navigation.navigate('EditProfile')} />
          <MenuItem icon={<IconHistory />}  label="Ride History"   sub="Past rides & receipts"    onPress={() => navigation.navigate('RideHistory')} />
          <MenuItem icon={<IconSettings />} label="Settings"       sub="Notifications, privacy"   onPress={() => navigation.navigate('Settings')} />
        </View>

        {/* ── Support section ── */}
        <View style={s.section}>
          <Text style={s.sectionTitle}>Support</Text>
          <MenuItem icon={<IconAlert />}    label="Report a Problem"  sub="We respond within 24h"  onPress={() => setReportVisible(true)} />
          <MenuItem icon={<IconMail />}     label="Contact Us"        sub={SUPPORT_EMAIL}           onPress={() => Linking.openURL(`mailto:${SUPPORT_EMAIL}`).catch(() => {})} />
        </View>

        {/* ── Sponsor card ── */}
        <TouchableOpacity style={s.sponsorCard} onPress={openSponsor} activeOpacity={0.8}>
          <View style={s.sponsorLeft}>
            <Text style={s.sponsorEmoji}>💛</Text>
            <View>
              <Text style={s.sponsorTitle}>Become a Sponsor</Text>
              <Text style={s.sponsorSub}>Partner with GoShareX · Reach AIUB students</Text>
            </View>
          </View>
          <IconChevron />
        </TouchableOpacity>

        {/* ── App info ── */}
        <View style={s.appInfo}>
          <Text style={s.appName}>GoShareX</Text>
          <Text style={s.appTagline}>ভাড়া ভাগ করো, টাকা বাঁচাও 🛺</Text>
          <Text style={s.appVersion}>v1.0.0 · Built for AIUB · © 2025</Text>
        </View>

        {/* ── Logout ── */}
        <TouchableOpacity style={s.logoutBtn} onPress={handleLogout} activeOpacity={0.8}>
          <IconLogout />
          <Text style={s.logoutTxt}>Sign Out</Text>
        </TouchableOpacity>

      </Animated.ScrollView>

      <ReportModal visible={reportVisible} onClose={() => setReportVisible(false)} userEmail={profile?.email} />
    </View>
  );
}

// ─── Stat card styles ─────────────────────────────────────────────────────────
const sc = StyleSheet.create({
  card: {
    flex: 1,
    minWidth: (SW - 44) / 2,
    maxWidth: (SW - 44) / 2,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    marginBottom: 0,
  },
  iconBox: {
    width: 32,
    height: 32,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  val: { fontSize: 22, fontWeight: '900', letterSpacing: -0.5, marginBottom: 2 },
  lbl: { fontSize: 11, color: '#8892A4', fontWeight: '600' },
  bar: { height: 3, borderRadius: 2, backgroundColor: '#E5E7EB', marginTop: 10, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: 2 },
});

// ─── Menu item styles ─────────────────────────────────────────────────────────
const mi = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 13,
    paddingHorizontal: 16,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
    gap: 12,
  },
  iconWrap: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  texts: { flex: 1 },
  label: { color: '#111827', fontSize: 13, fontWeight: '700' },
  sub: { color: '#9CA3AF', fontSize: 11, fontWeight: '500', marginTop: 1 },
});

// ─── Report modal styles ──────────────────────────────────────────────────────
const rm = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 36 },
  handle: { width: 36, height: 4, borderRadius: 2, backgroundColor: '#E5E7EB', alignSelf: 'center', marginBottom: 20 },
  title: { color: '#111827', fontSize: 17, fontWeight: '800', marginBottom: 4 },
  sub: { color: '#9CA3AF', fontSize: 12, fontWeight: '500', marginBottom: 16 },
  input: {
    backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB',
    borderRadius: 12, padding: 14, color: '#111827', fontSize: 13, fontWeight: '500',
    textAlignVertical: 'top', minHeight: 100, marginBottom: 16,
  },
  btnRow: { flexDirection: 'row', gap: 10 },
  cancel: { flex: 1, backgroundColor: '#F3F4F6', borderRadius: 12, paddingVertical: 13, alignItems: 'center' },
  cancelTxt: { color: '#6B7280', fontSize: 14, fontWeight: '700' },
  send: { flex: 1, backgroundColor: '#7C3AED', borderRadius: 12, paddingVertical: 13, alignItems: 'center' },
  sendDim: { backgroundColor: '#DDD6FE', opacity: 0.6 },
  sendTxt: { color: '#FFF', fontSize: 14, fontWeight: '800' },
});

// ─── Screen styles ────────────────────────────────────────────────────────────
const s = StyleSheet.create({
  // Hero
  hero: {
    backgroundColor: C.card,
    borderRadius: 20,
    padding: 18,
    borderWidth: 1,
    borderColor: C.cardBorder,
    marginBottom: 12,
    overflow: 'hidden',
    position: 'relative',
    shadowColor: '#7C3AED',
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  glow: { position: 'absolute', width: 140, height: 140, borderRadius: 70 },
  heroRow: { flexDirection: 'row', gap: 14, marginBottom: 16 },

  avatarWrap: { position: 'relative' },
  avatarRing: { width: 80, height: 80, borderRadius: 40, borderWidth: 2, padding: 3 },
  avatarBg: { flex: 1, borderRadius: 36, alignItems: 'center', justifyContent: 'center' },
  avatarLetter: { fontSize: 32, fontWeight: '900' },
  onlineDot: {
    position: 'absolute', bottom: 2, right: 2,
    width: 16, height: 16, borderRadius: 8,
    backgroundColor: '#10B981', borderWidth: 2, borderColor: C.card,
  },

  name: { color: C.text, fontSize: 18, fontWeight: '800', marginBottom: 2 },
  email: { color: C.textMuted, fontSize: 11, fontWeight: '500', marginBottom: 8 },

  badgeRow: { flexDirection: 'row', gap: 8, alignItems: 'center', flexWrap: 'wrap' },
  badgePill: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, borderWidth: 1,
  },
  badgeEmoji: { fontSize: 11 },
  badgeLabel: { fontSize: 11, fontWeight: '700' },
  ratingPill: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 8, paddingVertical: 4, borderRadius: 20,
    backgroundColor: 'rgba(245,158,11,0.14)', borderWidth: 1, borderColor: 'rgba(245,158,11,0.3)',
  },
  ratingTxt: { color: C.amber, fontSize: 11, fontWeight: '800' },
  joinedTxt: { color: C.textMuted, fontSize: 10, marginTop: 6 },

  // Badge progress
  progressSection: { marginBottom: 14 },
  progressLabelRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  progressLabel: { color: C.textSub, fontSize: 11, fontWeight: '600' },
  progressPct: { fontSize: 11, fontWeight: '700' },
  progressTrack: { height: 5, borderRadius: 3, backgroundColor: '#E5E7EB', overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 3 },

  // Quick numbers
  quickRow: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: '#E8ECF4',
    paddingTop: 14,
  },
  quickItem: { flex: 1, alignItems: 'center' },
  quickBorder: { borderLeftWidth: 1, borderLeftColor: '#E8ECF4' },
  quickVal: { color: C.text, fontSize: 16, fontWeight: '900', letterSpacing: -0.3 },
  quickLbl: { color: C.textMuted, fontSize: 10, fontWeight: '600', marginTop: 2 },

  // Stats grid
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 12 },

  // Strikes banner
  strikeBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: '#FEF2F2',
    borderWidth: 1,
    borderColor: '#FECACA',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
  },
  strikeTxt: { flex: 1, color: '#DC2626', fontSize: 12, fontWeight: '600', lineHeight: 16 },

  // Section
  section: {
    backgroundColor: C.card,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.cardBorder,
    marginBottom: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  sectionTitle: {
    color: C.textMuted,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 4,
  },

  // Sponsor card
  sponsorCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFBEB',
    borderWidth: 1,
    borderColor: '#FDE68A',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#F59E0B',
    shadowOpacity: 0.08,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  sponsorLeft: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12 },
  sponsorEmoji: { fontSize: 28 },
  sponsorTitle: { color: '#92400E', fontSize: 14, fontWeight: '800', marginBottom: 2 },
  sponsorSub: { color: '#B45309', fontSize: 11, fontWeight: '500' },

  // App info
  appInfo: { alignItems: 'center', paddingVertical: 20, gap: 4 },
  appName: { color: C.primary, fontSize: 18, fontWeight: '900', letterSpacing: -0.5 },
  appTagline: { color: C.textSub, fontSize: 12, fontWeight: '600' },
  appVersion: { color: C.textMuted, fontSize: 10, fontWeight: '500' },

  // Logout
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#FEF2F2',
    borderWidth: 1,
    borderColor: '#FECACA',
    borderRadius: 14,
    paddingVertical: 14,
    marginBottom: 8,
  },
  logoutTxt: { color: C.red, fontSize: 14, fontWeight: '800' },
});

// ─── Trust card styles ────────────────────────────────────────────────────────
const tc = StyleSheet.create({
  wrap: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E8ECF4',
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  header:     { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 },
  title:      { color: '#111827', fontSize: 14, fontWeight: '800', marginBottom: 2 },
  sub:        { color: '#9CA3AF', fontSize: 11, fontWeight: '500' },
  scoreBadge: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 6, alignItems: 'center', flexDirection: 'row', gap: 2 },
  scoreNum:   { fontSize: 22, fontWeight: '900', letterSpacing: -0.5 },
  scoreOf:    { fontSize: 11, fontWeight: '700', marginTop: 4 },

  starRow:    { flexDirection: 'row', alignItems: 'center', gap: 3, marginBottom: 14 },
  starNum:    { color: '#D97706', fontSize: 14, fontWeight: '800', marginLeft: 6 },

  cats:       { gap: 10 },
  catRow:     { flexDirection: 'row', alignItems: 'center', gap: 8 },
  catEmoji:   { fontSize: 14, width: 20, textAlign: 'center' },
  catLabel:   { color: '#6B7280', fontSize: 12, fontWeight: '600', width: 90 },
  barTrack:   { flex: 1, height: 6, borderRadius: 3, backgroundColor: '#F3F4F6', overflow: 'hidden' },
  barFill:    { height: '100%', borderRadius: 3 },
  catPct:     { fontSize: 12, fontWeight: '800', width: 36, textAlign: 'right' },

  anonNote:   { marginTop: 14, fontSize: 10, color: '#9CA3AF', textAlign: 'center', fontStyle: 'italic' },
});
