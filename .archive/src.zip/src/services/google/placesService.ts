import ENV from '@/config/env';

import { buildQueryString, fetchJson, GOOGLE_API_ENDPOINTS } from './base';

export interface PlaceSuggestion {
  placeId: string;
  primaryText: string;
  secondaryText: string;
  description: string;
}

interface PlacesAutocompleteResponse {
  predictions: Array<{
    description: string;
    place_id: string;
    structured_formatting?: {
      main_text?: string;
      secondary_text?: string;
    };
  }>;
  status: string;
  error_message?: string;
}

interface PlacesNearbySearchResponse {
  results: Array<{
    place_id: string;
    name: string;
    vicinity?: string;
    geometry?: {
      location?: {
        lat: number;
        lng: number;
      };
    };
  }>;
  status: string;
  error_message?: string;
}

interface PlaceDetailsResponse {
  result?: {
    place_id?: string;
    name?: string;
    formatted_address?: string;
    geometry?: {
      location?: {
        lat: number;
        lng: number;
      };
    };
  };
  status: string;
  error_message?: string;
}

class PlacesService {
  async autocomplete(params: {
    input: string;
    latitude?: number;
    longitude?: number;
    radiusMeters?: number;
    sessionToken?: string;
    language?: string;
  }): Promise<PlaceSuggestion[]> {
    if (!ENV.googlePlacesApiKey || ENV.googlePlacesApiKey === 'placeholder') {
      throw new Error('Google Places API key is missing at runtime');
    }

    const query = buildQueryString({
      input: params.input.trim(),
      key: ENV.googlePlacesApiKey,
      language: params.language ?? 'en',
      sessiontoken: params.sessionToken,
      location:
        params.latitude !== undefined && params.longitude !== undefined
          ? `${params.latitude},${params.longitude}`
          : undefined,
      radius: params.radiusMeters ?? 10000,
    });

    const data = await fetchJson<PlacesAutocompleteResponse>(
      `${GOOGLE_API_ENDPOINTS.placesAutocomplete}?${query}`
    );

    if (data.status !== 'OK' && data.status !== 'ZERO_RESULTS') {
      throw new Error(data.error_message || `Places autocomplete failed: ${data.status}`);
    }

    return (data.predictions ?? []).map((prediction) => ({
      placeId: prediction.place_id,
      description: prediction.description,
      primaryText: prediction.structured_formatting?.main_text ?? prediction.description,
      secondaryText: prediction.structured_formatting?.secondary_text ?? '',
    }));
  }

  async findNearbyRickshawStands(params: {
    latitude: number;
    longitude: number;
    radiusMeters?: number;
    keyword?: string;
  }) {
    if (!ENV.googlePlacesApiKey || ENV.googlePlacesApiKey === 'placeholder') {
      throw new Error('Google Places API key is missing at runtime');
    }

    const query = buildQueryString({
      key: ENV.googlePlacesApiKey,
      location: `${params.latitude},${params.longitude}`,
      radius: params.radiusMeters ?? 300,
      keyword: params.keyword ?? 'rickshaw stand',
    });

    const data = await fetchJson<PlacesNearbySearchResponse>(
      `${GOOGLE_API_ENDPOINTS.placesNearbySearch}?${query}`
    );

    if (data.status !== 'OK' && data.status !== 'ZERO_RESULTS') {
      throw new Error(data.error_message || `Places nearby search failed: ${data.status}`);
    }

    return (data.results ?? []).map((item) => ({
      placeId: item.place_id,
      name: item.name,
      address: item.vicinity ?? '',
      latitude: item.geometry?.location?.lat ?? 0,
      longitude: item.geometry?.location?.lng ?? 0,
    }));
  }

  async getPlaceDetails(params: { placeId: string; language?: string }) {
    if (!ENV.googlePlacesApiKey || ENV.googlePlacesApiKey === 'placeholder') {
      throw new Error('Google Places API key is missing at runtime');
    }

    const query = buildQueryString({
      key: ENV.googlePlacesApiKey,
      place_id: params.placeId,
      language: params.language ?? 'en',
      fields: 'place_id,name,formatted_address,geometry',
    });

    const data = await fetchJson<PlaceDetailsResponse>(
      `${GOOGLE_API_ENDPOINTS.placesDetails}?${query}`
    );

    if (data.status !== 'OK' || !data.result?.geometry?.location) {
      throw new Error(data.error_message || `Place details failed: ${data.status}`);
    }

    return {
      placeId: data.result.place_id ?? params.placeId,
      name: data.result.name ?? 'Selected place',
      address: data.result.formatted_address ?? '',
      latitude: data.result.geometry.location.lat,
      longitude: data.result.geometry.location.lng,
    };
  }
}

export default new PlacesService();
