import {
  collection,
  doc,
  addDoc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
  setDoc,
  getDoc,
  getDocs,
  deleteDoc,
  writeBatch,
  limit,
  where,
  runTransaction,
} from 'firebase/firestore';
import { db } from '@/config/firebase.config';

export type ChatMode = 'ride' | 'anonymous_1v1' | 'anonymous_group';

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
  type: 'text' | 'quick_reply' | 'location' | 'system';
}

export interface Chat {
  id: string;
  participants: string[];
  participantNames: Record<string, string>;
  participantAliases?: Record<string, string>;
  rideId?: string;
  destination: string;
  fare: number;
  mode?: ChatMode;
  anonymous?: boolean;
  expiresAt?: number;
  searching?: boolean;
  minParticipants?: number;
  maxParticipants?: number;
  lastMessage?: string;
  lastMessageTime?: number;
  dealConfirmed?: Record<string, boolean>;
}

class ChatService {
  private readonly anonymousDurationMs = 15 * 60 * 1000;

  private buildAnonymousAlias(position: number): string {
    return `Anonymous ${position}`;
  }

  private async appendSystemMessage(chatId: string, text: string): Promise<void> {
    const messagesRef = collection(db, 'chats', chatId, 'messages');
    await addDoc(messagesRef, {
      senderId: 'system',
      senderName: 'System',
      text,
      type: 'system',
      timestamp: Date.now(),
      createdAt: serverTimestamp(),
    });
  }

  // Create or get existing chat between 2 users
  async getOrCreateChat(
    user1Id: string,
    user1Name: string,
    user2Id: string,
    user2Name: string,
    destination: string,
    fare: number,
    rideId?: string
  ): Promise<string> {
    const chatId = [user1Id, user2Id].sort().join('_');
    const chatRef = doc(db, 'chats', chatId);
    const existing = await getDoc(chatRef);

    if (!existing.exists()) {
      await setDoc(chatRef, {
        participants: [user1Id, user2Id],
        participantNames: { [user1Id]: user1Name, [user2Id]: user2Name },
        destination,
        fare,
        mode: 'ride',
        anonymous: false,
        rideId: rideId ?? null,
        createdAt: serverTimestamp(),
        dealConfirmed: { [user1Id]: false, [user2Id]: false },
        lastMessage: '',
        lastMessageTime: Date.now(),
      });
    }
    return chatId;
  }

  async startAnonymousOneToOne(userId: string): Promise<string> {
    const chatsRef = collection(db, 'chats');
    const waitingQuery = query(
      chatsRef,
      where('mode', '==', 'anonymous_1v1'),
      where('searching', '==', true),
      limit(10)
    );
    const waitingRooms = await getDocs(waitingQuery);
    const now = Date.now();

    for (const roomDoc of waitingRooms.docs) {
      const room = roomDoc.data() as Chat;
      const alreadyJoined = room.participants?.includes(userId);
      const expired = !!room.expiresAt && room.expiresAt <= now;
      const hasSlot = (room.participants?.length ?? 0) < 2;

      if (alreadyJoined || expired || !hasSlot) {
        continue;
      }

      const joinedId = await runTransaction(db, async (transaction) => {
        const latest = await transaction.get(roomDoc.ref);
        if (!latest.exists()) return null;

        const data = latest.data() as Chat;
        if (
          data.searching !== true ||
          (data.participants?.length ?? 0) >= 2 ||
          (data.expiresAt ?? 0) <= Date.now() ||
          data.participants?.includes(userId)
        ) {
          return null;
        }

        const participants = [...(data.participants ?? []), userId];
        const aliases = {
          ...(data.participantAliases ?? {}),
          [userId]: this.buildAnonymousAlias(participants.length),
        };

        transaction.set(
          roomDoc.ref,
          {
            participants,
            participantAliases: aliases,
            participantNames: aliases,
            searching: false,
            lastMessageTime: Date.now(),
          },
          { merge: true }
        );

        return roomDoc.id;
      });

      if (joinedId) {
        await this.appendSystemMessage(joinedId, 'Another anonymous user joined. You can start chatting now.');
        return joinedId;
      }
    }

    const roomRef = doc(chatsRef);
    const expiresAt = Date.now() + this.anonymousDurationMs;
    await setDoc(roomRef, {
      participants: [userId],
      participantNames: { [userId]: this.buildAnonymousAlias(1) },
      participantAliases: { [userId]: this.buildAnonymousAlias(1) },
      destination: 'Anonymous 1:1',
      fare: 0,
      mode: 'anonymous_1v1',
      anonymous: true,
      searching: true,
      minParticipants: 2,
      maxParticipants: 2,
      expiresAt,
      createdAt: serverTimestamp(),
      dealConfirmed: { [userId]: false },
      lastMessage: '',
      lastMessageTime: Date.now(),
    });

    await this.appendSystemMessage(roomRef.id, 'Anonymous room created. Waiting for another person to join.');

    return roomRef.id;
  }

  async startAnonymousGroup(userId: string): Promise<string> {
    const chatsRef = collection(db, 'chats');
    const waitingQuery = query(
      chatsRef,
      where('mode', '==', 'anonymous_group'),
      where('searching', '==', true),
      limit(10)
    );
    const waitingRooms = await getDocs(waitingQuery);
    const now = Date.now();

    for (const roomDoc of waitingRooms.docs) {
      const room = roomDoc.data() as Chat;
      const alreadyJoined = room.participants?.includes(userId);
      const expired = !!room.expiresAt && room.expiresAt <= now;
      const hasSlot = (room.participants?.length ?? 0) < 10;

      if (alreadyJoined || expired || !hasSlot) {
        continue;
      }

      const joinedId = await runTransaction(db, async (transaction) => {
        const latest = await transaction.get(roomDoc.ref);
        if (!latest.exists()) return null;

        const data = latest.data() as Chat;
        const currentParticipants = data.participants ?? [];
        if (
          data.searching !== true ||
          currentParticipants.length >= 10 ||
          (data.expiresAt ?? 0) <= Date.now() ||
          currentParticipants.includes(userId)
        ) {
          return null;
        }

        const participants = [...currentParticipants, userId];
        const aliases = {
          ...(data.participantAliases ?? {}),
          [userId]: this.buildAnonymousAlias(participants.length),
        };

        transaction.set(
          roomDoc.ref,
          {
            participants,
            participantAliases: aliases,
            participantNames: aliases,
            searching: participants.length < 10,
            lastMessageTime: Date.now(),
          },
          { merge: true }
        );

        return roomDoc.id;
      });

      if (joinedId) {
        await this.appendSystemMessage(joinedId, 'A new anonymous member joined the group.');
        return joinedId;
      }
    }

    const roomRef = doc(chatsRef);
    const expiresAt = Date.now() + this.anonymousDurationMs;
    await setDoc(roomRef, {
      participants: [userId],
      participantNames: { [userId]: this.buildAnonymousAlias(1) },
      participantAliases: { [userId]: this.buildAnonymousAlias(1) },
      destination: 'Anonymous Group',
      fare: 0,
      mode: 'anonymous_group',
      anonymous: true,
      searching: true,
      minParticipants: 2,
      maxParticipants: 10,
      expiresAt,
      createdAt: serverTimestamp(),
      dealConfirmed: { [userId]: false },
      lastMessage: '',
      lastMessageTime: Date.now(),
    });

    await this.appendSystemMessage(roomRef.id, 'Anonymous group created. Waiting for more members.');

    return roomRef.id;
  }

  // Send a message
  async sendMessage(
    chatId: string,
    senderId: string,
    senderName: string,
    text: string,
    type: Message['type'] = 'text'
  ): Promise<void> {
    const messagesRef = collection(db, 'chats', chatId, 'messages');
    await addDoc(messagesRef, {
      senderId,
      senderName,
      text,
      type,
      timestamp: Date.now(),
      createdAt: serverTimestamp(),
    });

    // Update last message on chat doc
    const chatRef = doc(db, 'chats', chatId);
    await setDoc(chatRef, { lastMessage: text, lastMessageTime: Date.now() }, { merge: true });
  }

  // Listen to messages real-time
  listenToMessages(chatId: string, callback: (messages: Message[]) => void): () => void {
    const q = query(
      collection(db, 'chats', chatId, 'messages'),
      orderBy('timestamp', 'asc')
    );
    return onSnapshot(q, (snapshot) => {
      const msgs: Message[] = snapshot.docs.map((d) => ({
        id: d.id,
        ...(d.data() as Omit<Message, 'id'>),
      }));
      callback(msgs);
    });
  }

  // Confirm deal (both must press)
  async confirmDeal(chatId: string, userId: string): Promise<boolean> {
    const chatRef = doc(db, 'chats', chatId);
    await setDoc(chatRef, { [`dealConfirmed.${userId}`]: true }, { merge: true });

    const updated = await getDoc(chatRef);
    const data = updated.data();
    if (!data) return false;

    const confirmed = data.dealConfirmed as Record<string, boolean>;
    return Object.values(confirmed).every(Boolean);
  }

  // Listen to chat metadata (deal status etc)
  listenToChat(chatId: string, callback: (chat: Partial<Chat>) => void): () => void {
    return onSnapshot(doc(db, 'chats', chatId), (snap) => {
      if (snap.exists()) callback(snap.data() as Partial<Chat>);
    });
  }

  // Delete all messages in a 1v1 chat after session ends (privacy)
  async deleteOneToOneHistory(chatId: string): Promise<void> {
    try {
      const messagesRef = collection(db, 'chats', chatId, 'messages');
      const snap = await getDocs(messagesRef);
      const batch = writeBatch(db);
      snap.docs.forEach((d) => batch.delete(d.ref));
      await batch.commit();
      // Mark the chat doc as history cleared
      await setDoc(doc(db, 'chats', chatId), {
        lastMessage: 'Session ended — messages cleared',
        lastMessageTime: Date.now(),
        historyCleared: true,
      }, { merge: true });
    } catch {
      // Best-effort cleanup — silent fail
    }
  }

  // Delete entire anonymous room (doc + messages) after expiry
  async deleteAnonymousRoom(chatId: string): Promise<void> {
    try {
      const messagesRef = collection(db, 'chats', chatId, 'messages');
      const snap = await getDocs(messagesRef);
      const batch = writeBatch(db);
      snap.docs.forEach((d) => batch.delete(d.ref));
      batch.delete(doc(db, 'chats', chatId));
      await batch.commit();
    } catch {
      // silent
    }
  }
}

export default new ChatService();
