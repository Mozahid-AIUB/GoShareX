import * as Location from 'expo-location';
import { ref, set, onValue, off } from 'firebase/database';
import { realtimeDb } from '@/config/firebase.config';
import { auth } from '@/config/firebase.config';
import ENV from '@/config/env';
import type { ActiveRiderRaw } from '@/services/firebase/matchingService';

export interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
  address?: string;
}

/**
 * Location Service
 * Handles GPS tracking and real-time location updates
 */
class LocationService {
  private watchSubscription: Location.LocationSubscription | null = null;
  private userId: string | null = null;
  private realtimeWriteDenied = false;
  private readonly targetAccuracyMeters = 20;

  private isPermissionDenied(error: unknown): boolean {
    const message = error instanceof Error ? error.message : String(error);
    return message.toUpperCase().includes('PERMISSION_DENIED');
  }

  /**
   * Request location permissions
   */
  async requestPermissions(): Promise<boolean> {
    try {
      const { status: foregroundStatus } = await Location.requestForegroundPermissionsAsync();

      if (foregroundStatus !== 'granted') {
        return false;
      }

      // Foreground permission is enough for showing the live map.
      // Background access can be requested later for ride tracking flows.
      return true;
    } catch (error) {
      console.error('Permission request error:', error);
      return false;
    }
  }

  /**
   * Get current location
   */
  async getCurrentLocation(): Promise<LocationData | null> {
    try {
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Highest,
      });

      return {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        accuracy: location.coords.accuracy || 0,
        timestamp: location.timestamp,
      };
    } catch (error) {
      console.error('Get location error:', error);
      return null;
    }
  }

  async getFreshCurrentLocation(options?: {
    maxAccuracyMeters?: number;
    timeoutMs?: number;
  }): Promise<LocationData | null> {
    const maxAccuracyMeters = options?.maxAccuracyMeters ?? this.targetAccuracyMeters;
    const timeoutMs = options?.timeoutMs ?? 12000;
    const startedAt = Date.now();
    let bestLocation: LocationData | null = null;

    while (Date.now() - startedAt < timeoutMs) {
      const current = await this.getCurrentLocation();
      if (current) {
        if (!bestLocation || current.accuracy < bestLocation.accuracy) {
          bestLocation = current;
        }

        if (current.accuracy > 0 && current.accuracy <= maxAccuracyMeters) {
          return current;
        }
      }

      await new Promise((resolve) => setTimeout(resolve, 1200));
    }

    return bestLocation;
  }

  async reverseGeocode(latitude: number, longitude: number): Promise<string | null> {
    try {
      const results = await Location.reverseGeocodeAsync({ latitude, longitude });
      const first = results[0];
      if (!first) return null;

      const parts = [
        first.name,
        first.street,
        first.district,
        first.city,
        first.region,
      ].filter(Boolean);

      return parts.length ? parts.join(', ') : null;
    } catch (error) {
      console.error('Reverse geocode error:', error);
      return null;
    }
  }

  /**
   * Start watching location
   */
  async startWatching(
    userId: string,
    destination: string,
    pickupPoint: string,
    onUpdate?: (location: LocationData) => void,
    userRating: number = 5,
    userBadge: string = 'New Rider',
    vehicleType: string = 'rickshaw',
  ): Promise<void> {
    try {
      this.userId = userId;
      this.realtimeWriteDenied = false;

      this.watchSubscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.Highest,
          timeInterval: ENV.locationUpdateInterval,
          distanceInterval: 5,
        },
        (location) => {
          const locationData: LocationData = {
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
            accuracy: location.coords.accuracy || 0,
            timestamp: location.timestamp,
          };

          // Update Firebase Realtime Database
          this.updateLocationInFirebase(userId, locationData, destination, pickupPoint, userRating, userBadge, vehicleType);

          // Callback
          if (onUpdate) {
            onUpdate(locationData);
          }
        }
      );
    } catch (error) {
      console.error('Start watching error:', error);
      throw error;
    }
  }

  /**
   * Stop watching location
   */
  async stopWatching(): Promise<void> {
    try {
      if (this.watchSubscription) {
        this.watchSubscription.remove();
        this.watchSubscription = null;
      }

      // Remove from active riders
      if (this.userId) {
        const userRef = ref(realtimeDb, `active_riders/${this.userId}`);
        if (!this.realtimeWriteDenied) {
          await set(userRef, null);
        }
        this.userId = null;
      }
    } catch (error) {
      if (!this.isPermissionDenied(error)) {
        console.error('Stop watching error:', error);
      }
    }
  }

  /**
   * Update location in Firebase
   */
  private async updateLocationInFirebase(
    userId: string,
    location: LocationData,
    destination: string,
    pickupPoint: string,
    userRating: number = 5,
    userBadge: string = 'New Rider',
    vehicleType: string = 'rickshaw',
  ): Promise<void> {
    try {
      if (this.realtimeWriteDenied) {
        return;
      }

      const userRef = ref(realtimeDb, `active_riders/${userId}`);
      const currentUser = auth.currentUser;
      const fallbackName =
        currentUser?.displayName?.trim() ||
        currentUser?.email?.split('@')[0] ||
        'Active Rider';

      await set(userRef, {
        uid: userId,
        name: fallbackName,
        lat: location.latitude,
        lng: location.longitude,
        destination,
        pickupPoint,
        rating: userRating,
        badge: userBadge,
        vehicleType,
        timestamp: location.timestamp,
        status: 'waiting',
      });
    } catch (error) {
      if (this.isPermissionDenied(error)) {
        this.realtimeWriteDenied = true;
        return;
      }

      console.error('Update location error:', error);
    }
  }

  /**
   * Get nearby riders
   */
  watchNearbyRiders(
    callback: (riders: ActiveRiderRaw[]) => void
  ): () => void {
    const ridersRef = ref(realtimeDb, 'active_riders');

    const unsubscribe = onValue(ridersRef, (snapshot) => {
      const data = snapshot.val() as Record<string, Omit<ActiveRiderRaw, 'id'>> | null;
      const riders: ActiveRiderRaw[] = data
        ? Object.entries(data).map(([id, rider]) => ({ id, ...rider }))
        : [];
      callback(riders);
    });

    return () => off(ridersRef, 'value', unsubscribe);
  }
}

export default new LocationService();