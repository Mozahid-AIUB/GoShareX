/**
 * Validation utilities for the app
 */

/** General email validation — accepts any valid email */
export const isValidEmail = (email: string): boolean => {
  return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email.trim().toLowerCase());
};

/** @deprecated Use isValidEmail instead */
export const isValidAIUBEmail = isValidEmail;
export const isAIUBEmail = isValidEmail;

/** @deprecated Student ID no longer required */
export const isValidStudentId = (_studentId: string): boolean => true;

/**
 * Validate phone number (Bangladesh format)
 */
export const isValidPhoneNumber = (phone: string): boolean => {
  // Bangladesh mobile: 01XXXXXXXXX (11 digits)
  const phoneRegex = /^01[3-9]\d{8}$/;
  return phoneRegex.test(phone.replace(/[\s-]/g, ''));
};

/**
 * Validate password strength
 */
export const isValidPassword = (password: string): { valid: boolean; message?: string } => {
  if (password.length < 6) {
    return { valid: false, message: 'Password must be at least 6 characters' };
  }
  if (!/[A-Z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one uppercase letter' };
  }
  if (!/[a-z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one lowercase letter' };
  }
  if (!/[0-9]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one number' };
  }
  return { valid: true };
};

/**
 * Sanitize user input
 */
export const sanitizeInput = (input: string): string => {
  return input.trim().replace(/[<>]/g, '');
};

/**
 * Validate name
 */
export const isValidName = (name: string): boolean => {
  return name.trim().length >= 2 && /^[a-zA-Z\s.]+$/.test(name);
};
