export interface PickupPoint {
  id: string;
  name: string;
  nameBn: string;
  lat: number;
  lng: number;
}

export const PICKUP_POINTS: PickupPoint[] = [
  { id: 'main_gate',    name: 'Main Gate',    nameBn: 'মেইন গেট',     lat: 23.8103, lng: 90.4125 },
  { id: 'gate2',        name: 'Gate 2',       nameBn: 'গেট ২',         lat: 23.8095, lng: 90.4138 },
  { id: 'canteen',      name: 'Canteen Area', nameBn: 'ক্যান্টিন',    lat: 23.8108, lng: 90.4131 },
  { id: 'parking',      name: 'Parking Zone', nameBn: 'পার্কিং জোন', lat: 23.8098, lng: 90.4120 },
  { id: 'admin_block',  name: 'Admin Block',  nameBn: 'অ্যাডমিন ব্লক', lat: 23.8112, lng: 90.4128 },
];

export const getPickupPointById = (id: string): PickupPoint | undefined =>
  PICKUP_POINTS.find(p => p.id === id);

export const getPickupPointByName = (name: string): PickupPoint | undefined =>
  PICKUP_POINTS.find(p => p.name === name || p.nameBn === name);
