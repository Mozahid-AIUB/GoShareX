import { useEffect } from 'react';
import { subscribeToNearbyRiders } from '@/services/ride/matchingService';
import { useRideStore } from '@/store';
import { useLocationStore } from '@/store';

export function useNearbyRiders(destination: string | null, enabled: boolean = true) {
  const { latitude, longitude } = useLocationStore();
  const { setNearbyRiders } = useRideStore();

  useEffect(() => {
    if (!enabled) {
      setNearbyRiders([]);
      return;
    }

    if (!latitude || !longitude || !destination) return;
    const unsubscribe = subscribeToNearbyRiders(
      { uid: 'self', lat: latitude, lng: longitude, destination },
      setNearbyRiders
    );
    return unsubscribe;
  }, [destination, enabled, latitude, longitude, setNearbyRiders]);
}
